# Desktop OS Simulation — Responsive Codespaces Edition

A responsive desktop-style web simulation built with Next.js. It includes Windows/macOS-inspired shells, movable app windows, Chrome/Discord-style demo apps, a playable in-site mini-game, and a lightweight scene editor.

## Run in GitHub Codespaces

```bash
corepack enable
pnpm install
pnpm dev
```

Open forwarded port **3000** in the browser.

If uploading this ZIP to a repository, extract its contents into the repository root (do not upload only the ZIP file).

## Apps

- File manager, notepad, calculator, settings
- Browser and Chrome-style demo interface
- Discord-style demo interface
- Roblox-inspired mini obstacle game that runs inside the site
- Roblox Studio-inspired scene editor with local scene saving and JSON export
- VM launcher

## Important limitations

This is a browser-based simulation, not a full OS emulator. Chrome/Discord are UI demos, not the native applications. The Roblox mini-game is an original in-site demo and does not load the Roblox engine or actual Roblox experiences. The Studio-inspired editor exports a JSON scene description, not a native `.rbxl` project. Use the official Roblox website/Studio for real accounts, games, and projects.

The desktop fills the browser viewport and open windows are resized/clamped when the viewport changes. Smaller screens automatically open app windows maximized.

## Quality and release checks

```bash
pnpm install --frozen-lockfile
pnpm typecheck
pnpm build
```

The production build is configured to fail on TypeScript errors; build errors are not ignored. Basic response hardening headers are enabled in `next.config.mjs` (MIME sniffing protection, referrer policy, same-origin framing, reduced browser permissions, and opener isolation). The `/api/health` endpoint can be used for a simple uptime probe.

Before a public or enterprise release, run the commands above in a network-enabled environment, then test current Chrome/Edge/Firefox/Safari and Android/iOS screen sizes, keyboard-only navigation, storage-disabled/private browsing, quota errors, and the VM launcher. This ZIP has not yet passed a full dependency install, typecheck, production build, penetration test, or cross-browser device matrix in this environment; do not treat it as production-certified. Authentication, server-side database persistence, email delivery, monitoring, backups, rate limiting, and an operational incident process are still required for a real enterprise service.

For public hosting, connect the repository to a Next.js-compatible host such as Vercel. GitHub Codespaces itself is a development environment, not permanent production hosting.


## Additional site portal and version selection
- Selectable version history spans early Windows releases through Windows 11 25H2-style UI, and early classic Mac releases through macOS 26-style UI.
- Available interface languages: Korean, English, Simplified Chinese, and Japanese.
- The fixed Help / Account panel includes About, Terms, prohibited-use/enforcement rules, contact, bug report, feedback, login, and sign-up prototype screens.
- Support/account forms currently save drafts only in the local browser. They do not send email, create secure accounts, or connect to a server. Add a server-side authentication provider and database before real public use.
- Version labels represent selectable visual simulation profiles; selecting a version does not boot that historical operating system.


## Glyph rendering and local persistence
- Added multilingual system-font fallback stacks for Korean, Simplified Chinese, Japanese and English to reduce missing-glyph square boxes. If a host OS lacks the relevant fonts, the browser's system fallback is used; this cannot guarantee every third-party font glyph.
- App launches are recorded in `localStorage` and can be reviewed from Help / Account → Activity history. History is device/browser-specific and can be cleared.
- Notes and configuration use browser storage where implemented. Browser storage may be erased by clearing site data and does not automatically synchronize between devices.
- For real cross-device persistence, account security, remote backups, and contact delivery, configure server-side authentication and a database. Do not store passwords or API secrets in browser storage.


## Fixes in the hardened build
- Fixed a malformed escaped newline in the Help / Account save handler that could prevent TypeScript parsing.
- Validate saved OS selection values before restoring them, and gracefully handle browser storage being unavailable or full.
- Validate activity-history records before rendering and guard history clearing against storage failures.
- Removed the TypeScript build-error bypass so production builds cannot silently skip type errors.
- Added conservative security response headers and disabled the default framework-identification header.
