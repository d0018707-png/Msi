const IMAGES: Record<string, { url: string; type: string }> = {
  kolibri: { url: 'https://i.copy.sh/kolibri.img', type: 'application/octet-stream' },
  freedos: { url: 'https://i.copy.sh/freedos722.img', type: 'application/octet-stream' },
  linux: { url: 'https://i.copy.sh/linux4.iso', type: 'application/x-iso9660-image' },
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const image = IMAGES[id]
  if (!image) return new Response('Not found', { status: 404 })

  const upstream = await fetch(image.url, { cache: 'force-cache' })
  if (!upstream.ok || !upstream.body) {
    return new Response('Upstream image unavailable', { status: 502 })
  }

  const headers = new Headers({
    'Content-Type': image.type,
    'Cache-Control': 'public, max-age=86400, immutable',
  })
  const length = upstream.headers.get('content-length')
  if (length) headers.set('Content-Length', length)

  return new Response(upstream.body, { status: 200, headers })
}
