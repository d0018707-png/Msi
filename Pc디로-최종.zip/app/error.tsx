'use client'

import { useEffect } from 'react'

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error('Web OS Emulator error:', error) }, [error])
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-zinc-950 px-6 text-center text-zinc-100">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-rose-400">오류가 발생했습니다</p>
      <h1 className="text-2xl font-semibold">화면을 불러오지 못했어요.</h1>
      <p className="max-w-md text-sm text-zinc-400">다시 시도해 주세요. 문제가 계속되면 개발 서버 로그를 확인하세요.</p>
      <button type="button" onClick={() => reset()} className="rounded-lg bg-sky-500 px-4 py-2 text-sm font-semibold text-zinc-950 hover:bg-sky-400">다시 시도</button>
    </main>
  )
}
