import Link from 'next/link'

export default function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-zinc-950 px-6 text-center text-zinc-100">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-400">404 · Not Found</p>
      <h1 className="text-3xl font-semibold">페이지를 찾을 수 없습니다</h1>
      <p className="max-w-md text-sm leading-6 text-zinc-400">주소를 확인하거나 홈 화면으로 돌아가세요.</p>
      <Link href="/" className="rounded-lg bg-sky-500 px-4 py-2 text-sm font-semibold text-zinc-950 hover:bg-sky-400">홈으로 돌아가기</Link>
    </main>
  )
}
