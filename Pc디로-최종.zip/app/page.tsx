import { OsRoot } from '@/components/os-root'

export default function Page() {
  return <OsRoot />
}
