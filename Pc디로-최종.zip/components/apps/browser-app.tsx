'use client'

import { useState } from 'react'
import { ArrowLeft, ArrowRight, Cloud, Lock, Mail, Map, Newspaper, Plus, RotateCw, Search, X } from 'lucide-react'
import type { OsFamily } from '@/lib/os-config'
import type { Translations } from '@/lib/i18n'
import { cn } from '@/lib/utils'

interface Tab {
  id: number
  query: string | null
  page: string | null
}

const SAMPLE_PAGES: Record<string, { title: string; body: string[] }> = {
  news: {
    title: 'Sample Daily',
    body: [
      'Browser-based prototypes are becoming a popular way to test product ideas quickly.',
      'Designers and engineers share interactive mockups that run entirely on the client.',
      'This is placeholder content generated locally. No network request was made.',
    ],
  },
  weather: {
    title: 'Weather · Seoul',
    body: ['18°C, partly cloudy', 'High 21° / Low 12°', 'Humidity 54% · Wind 3 m/s'],
  },
  mail: {
    title: 'Inbox (3)',
    body: ['Welcome to your sample mailbox', 'Weekly digest: 5 new updates', 'Your prototype has been shared'],
  },
  maps: {
    title: 'Maps',
    body: ['Map tiles are not loaded in offline mode.', 'Try searching for a place from the home page instead.'],
  },
}

export function BrowserApp({ os, strings }: { os: OsFamily; strings: Translations }) {
  const [tabs, setTabs] = useState<Tab[]>([{ id: 1, query: null, page: null }])
  const [activeId, setActiveId] = useState(1)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const active = tabs.find((t) => t.id === activeId) ?? tabs[0]
  const isMac = os === 'macos'

  function update(patch: Partial<Tab>) {
    setLoading(true)
    window.setTimeout(() => setLoading(false), 450)
    setTabs((ts) => ts.map((t) => (t.id === active.id ? { ...t, ...patch } : t)))
  }

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const q = input.trim()
    if (!q) return
    update({ query: q, page: null })
  }

  function newTab() {
    const id = Math.max(...tabs.map((t) => t.id)) + 1
    setTabs([...tabs, { id, query: null, page: null }])
    setActiveId(id)
    setInput('')
  }

  function closeTab(id: number) {
    if (tabs.length === 1) {
      setTabs([{ id: 1, query: null, page: null }])
      setActiveId(1)
      setInput('')
      return
    }
    const remaining = tabs.filter((t) => t.id !== id)
    setTabs(remaining)
    if (id === activeId) setActiveId(remaining[remaining.length - 1].id)
  }

  const address = active.page
    ? `sample://${active.page}`
    : active.query
      ? `sample://search?q=${encodeURIComponent(active.query)}`
      : 'sample://newtab'

  const tabTitle = (t: Tab) =>
    t.page ? SAMPLE_PAGES[t.page].title : t.query ? `${t.query} - ${strings.searchResults}` : strings.newTab

  const shortcuts = [
    { key: 'news', label: strings.news, Icon: Newspaper, color: 'bg-rose-100 text-rose-700' },
    { key: 'weather', label: strings.weather, Icon: Cloud, color: 'bg-sky-100 text-sky-700' },
    { key: 'mail', label: strings.mail, Icon: Mail, color: 'bg-amber-100 text-amber-700' },
    { key: 'maps', label: strings.maps, Icon: Map, color: 'bg-emerald-100 text-emerald-700' },
  ]

  return (
    <div className="flex h-full flex-col bg-white text-sm">
      <div className={cn('flex items-end gap-1 px-2 pt-1.5', isMac ? 'bg-zinc-100' : 'bg-zinc-200/70')}>
        <div role="tablist" className="flex min-w-0 flex-1 gap-1 overflow-x-auto">
          {tabs.map((t) => (
            <div
              key={t.id}
              role="tab"
              aria-selected={t.id === activeId}
              tabIndex={0}
              onClick={() => {
                setActiveId(t.id)
                setInput(t.query ?? '')
              }}
              onKeyDown={(e) => e.key === 'Enter' && setActiveId(t.id)}
              className={cn(
                'group flex w-40 min-w-24 shrink cursor-default items-center gap-2 rounded-t-lg px-3 py-1.5 text-xs',
                t.id === activeId ? 'bg-white text-zinc-900' : 'text-zinc-600 hover:bg-white/60',
              )}
            >
              <span className="flex-1 truncate">{tabTitle(t)}</span>
              <button
                type="button"
                aria-label={strings.close}
                onClick={(e) => {
                  e.stopPropagation()
                  closeTab(t.id)
                }}
                className="rounded p-0.5 hover:bg-zinc-200"
              >
                <X className="size-3" />
              </button>
            </div>
          ))}
        </div>
        <button
          type="button"
          aria-label={strings.newTab}
          onClick={newTab}
          className="mb-1 rounded p-1 text-zinc-600 hover:bg-white/70"
        >
          <Plus className="size-4" />
        </button>
      </div>

      <form onSubmit={submit} className="flex items-center gap-1 border-b border-zinc-200 px-2 py-1.5">
        <button
          type="button"
          aria-label="Back"
          onClick={() => update({ query: null, page: null })}
          className="rounded p-1.5 text-zinc-600 hover:bg-zinc-100"
        >
          <ArrowLeft className="size-4" />
        </button>
        <button type="button" aria-label="Forward" disabled className="rounded p-1.5 text-zinc-300">
          <ArrowRight className="size-4" />
        </button>
        <button
          type="button"
          aria-label="Reload"
          onClick={() => update({})}
          className="rounded p-1.5 text-zinc-600 hover:bg-zinc-100"
        >
          <RotateCw className={cn('size-4', loading && 'animate-spin')} />
        </button>
        <label className="flex min-w-0 flex-1 items-center gap-2 rounded-full bg-zinc-100 px-3 py-1.5 focus-within:ring-2 focus-within:ring-sky-500">
          <Lock className="size-3.5 shrink-0 text-zinc-500" />
          <span className="sr-only">{strings.browserSearch}</span>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={address}
            className="min-w-0 flex-1 bg-transparent text-xs text-zinc-800 outline-none placeholder:text-zinc-500"
          />
        </label>
      </form>

      <div className="relative min-h-0 flex-1 overflow-y-auto">
        {loading && <div className="absolute inset-x-0 top-0 h-0.5 animate-pulse bg-sky-500" />}
        {active.page ? (
          <article className="mx-auto max-w-xl p-6">
            <h3 className="text-2xl font-semibold text-zinc-900">{SAMPLE_PAGES[active.page].title}</h3>
            <div className="mt-4 flex flex-col gap-3">
              {SAMPLE_PAGES[active.page].body.map((p) => (
                <p key={p} className="rounded-lg border border-zinc-200 p-3 text-zinc-700">
                  {p}
                </p>
              ))}
            </div>
          </article>
        ) : active.query ? (
          <div className="mx-auto max-w-xl p-6">
            <p className="text-xs text-zinc-500">
              {strings.searchResults}: “{active.query}”
            </p>
            <ul className="mt-4 flex flex-col gap-5">
              {[1, 2, 3, 4].map((n) => (
                <li key={n}>
                  <p className="text-xs text-emerald-700">sample://result/{n}</p>
                  <button
                    type="button"
                    onClick={() => update({ page: Object.keys(SAMPLE_PAGES)[n - 1], query: null })}
                    className="text-left text-base text-blue-700 hover:underline"
                  >
                    {active.query} — Sample result {n}
                  </button>
                  <p className="text-xs leading-relaxed text-zinc-600">{strings.browserNotice}</p>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="flex flex-col items-center px-6 py-10">
            <h3 className="text-balance text-center text-2xl font-semibold text-zinc-800">
              {strings.browserHeadline}
            </h3>
            <form
              onSubmit={submit}
              className="mt-5 flex w-full max-w-md items-center gap-2 rounded-full border border-zinc-300 px-4 py-2.5 shadow-sm focus-within:ring-2 focus-within:ring-sky-500"
            >
              <Search className="size-4 text-zinc-500" />
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                aria-label={strings.browserSearch}
                placeholder={strings.browserSearch}
                className="flex-1 bg-transparent text-sm outline-none"
              />
            </form>
            <p className="mt-8 text-xs font-medium text-zinc-500">{strings.quickLinks}</p>
            <div className="mt-3 grid grid-cols-4 gap-4">
              {shortcuts.map(({ key, label, Icon, color }) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => update({ page: key, query: null })}
                  className="flex flex-col items-center gap-1.5 rounded-lg p-2 hover:bg-zinc-100"
                >
                  <span className={cn('flex size-11 items-center justify-center rounded-full', color)}>
                    <Icon className="size-5" />
                  </span>
                  <span className="text-xs text-zinc-700">{label}</span>
                </button>
              ))}
            </div>
            <p className="mt-10 rounded-full bg-zinc-100 px-3 py-1 text-[11px] text-zinc-500">{strings.offline}</p>
          </div>
        )}
      </div>
    </div>
  )
}
