'use client'

import { useState } from 'react'
import type { OsFamily } from '@/lib/os-config'
import { cn } from '@/lib/utils'

type Op = '+' | '−' | '×' | '÷'

function compute(a: number, b: number, op: Op) {
  switch (op) {
    case '+':
      return a + b
    case '−':
      return a - b
    case '×':
      return a * b
    case '÷':
      return b === 0 ? NaN : a / b
  }
}

function format(n: number) {
  if (!Number.isFinite(n)) return 'Error'
  const rounded = Number.parseFloat(n.toPrecision(12))
  return String(rounded)
}

export function CalculatorApp({ os, label }: { os: OsFamily; label: string }) {
  const [display, setDisplay] = useState('0')
  const [stored, setStored] = useState<number | null>(null)
  const [op, setOp] = useState<Op | null>(null)
  const [fresh, setFresh] = useState(true)
  const [history, setHistory] = useState('')

  function inputDigit(d: string) {
    if (display === 'Error' || fresh) {
      setDisplay(d === '.' ? '0.' : d)
      setFresh(false)
      return
    }
    if (d === '.' && display.includes('.')) return
    if (display.replace(/[-.]/g, '').length >= 14) return
    setDisplay(display === '0' && d !== '.' ? d : display + d)
  }

  function chooseOp(next: Op) {
    const current = Number.parseFloat(display)
    if (stored !== null && op && !fresh) {
      const result = compute(stored, current, op)
      setDisplay(format(result))
      setStored(result)
    } else {
      setStored(current)
    }
    setHistory(`${format(stored !== null && op && !fresh ? compute(stored, current, op) : current)} ${next}`)
    setOp(next)
    setFresh(true)
  }

  function equals() {
    if (stored === null || !op) return
    const current = Number.parseFloat(display)
    const result = compute(stored, current, op)
    setHistory(`${format(stored)} ${op} ${format(current)} =`)
    setDisplay(format(result))
    setStored(null)
    setOp(null)
    setFresh(true)
  }

  function clearAll() {
    setDisplay('0')
    setStored(null)
    setOp(null)
    setFresh(true)
    setHistory('')
  }

  function handleKey(e: React.KeyboardEvent) {
    const k = e.key
    if (/^[0-9.]$/.test(k)) inputDigit(k)
    else if (k === '+') chooseOp('+')
    else if (k === '-') chooseOp('−')
    else if (k === '*') chooseOp('×')
    else if (k === '/') {
      e.preventDefault()
      chooseOp('÷')
    } else if (k === 'Enter' || k === '=') equals()
    else if (k === 'Escape') clearAll()
    else if (k === 'Backspace' && !fresh) setDisplay(display.length > 1 ? display.slice(0, -1) : '0')
    else return
    e.preventDefault()
  }

  const isMac = os === 'macos'
  const keys: { label: string; kind: 'num' | 'op' | 'fn'; action: () => void; wide?: boolean }[] = [
    { label: 'AC', kind: 'fn', action: clearAll },
    {
      label: '±',
      kind: 'fn',
      action: () => display !== 'Error' && setDisplay(format(-Number.parseFloat(display))),
    },
    {
      label: '%',
      kind: 'fn',
      action: () => display !== 'Error' && setDisplay(format(Number.parseFloat(display) / 100)),
    },
    { label: '÷', kind: 'op', action: () => chooseOp('÷') },
    ...['7', '8', '9'].map((d) => ({ label: d, kind: 'num' as const, action: () => inputDigit(d) })),
    { label: '×', kind: 'op', action: () => chooseOp('×') },
    ...['4', '5', '6'].map((d) => ({ label: d, kind: 'num' as const, action: () => inputDigit(d) })),
    { label: '−', kind: 'op', action: () => chooseOp('−') },
    ...['1', '2', '3'].map((d) => ({ label: d, kind: 'num' as const, action: () => inputDigit(d) })),
    { label: '+', kind: 'op', action: () => chooseOp('+') },
    { label: '0', kind: 'num', action: () => inputDigit('0'), wide: true },
    { label: '.', kind: 'num', action: () => inputDigit('.') },
    { label: '=', kind: 'op', action: equals },
  ]

  return (
    <div
      tabIndex={0}
      onKeyDown={handleKey}
      aria-label={label}
      className={cn(
        'flex h-full flex-col p-3 outline-none',
        isMac ? 'bg-zinc-800 text-white' : 'bg-zinc-100 text-zinc-900',
      )}
    >
      <div className="flex flex-1 flex-col items-end justify-end px-2 pb-3" aria-live="polite">
        <span className={cn('h-5 text-sm', isMac ? 'text-zinc-400' : 'text-zinc-500')}>{history}</span>
        <output className="max-w-full truncate text-5xl font-light tabular-nums">{display}</output>
      </div>
      <div className="grid grid-cols-4 gap-1.5">
        {keys.map((k) => (
          <button
            key={k.label}
            type="button"
            onClick={k.action}
            className={cn(
              'h-12 text-lg font-medium transition-colors active:scale-95 focus-visible:outline-2 focus-visible:outline-sky-500',
              isMac ? 'rounded-full' : 'rounded-md',
              k.wide && 'col-span-2',
              k.kind === 'op' &&
                (isMac
                  ? 'bg-orange-500 hover:bg-orange-400'
                  : k.label === '='
                    ? 'bg-sky-700 text-white hover:bg-sky-600'
                    : 'bg-zinc-200 hover:bg-zinc-300'),
              k.kind === 'fn' && (isMac ? 'bg-zinc-500 hover:bg-zinc-400' : 'bg-zinc-200 hover:bg-zinc-300'),
              k.kind === 'num' && (isMac ? 'bg-zinc-600 hover:bg-zinc-500' : 'bg-white hover:bg-zinc-50'),
              op === k.label && fresh && isMac && 'bg-white text-orange-500',
            )}
          >
            {k.label}
          </button>
        ))}
      </div>
    </div>
  )
}
