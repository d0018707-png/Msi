'use client'

import type { Language } from '@/lib/os-config'

export function DiscordApp({ language }: { language: Language }) {
  const isKo = language === 'ko'
  const isJa = language === 'ja'
  const isZh = language === 'zh'

  const labels = {
    title: isKo ? 'Discord' : isJa ? 'Discord' : isZh ? 'Discord' : 'Discord',
    description: isKo
      ? '실제 Discord 웹사이트를 엽니다. 로그인, 서버, 메시지 및 음성 기능은 Discord 공식 서비스에서 이용할 수 있습니다.'
      : isJa
        ? 'Discord公式サイトを開きます。ログイン、サーバー、メッセージ、音声機能はDiscordで利用できます。'
        : isZh
          ? '打开 Discord 官方网站。登录、服务器、消息和语音功能由 Discord 官方服务提供。'
          : 'Open the official Discord website. Sign-in, servers, messages, and voice features are provided by Discord.',
    button: isKo ? 'Discord 열기' : isJa ? 'Discordを開く' : isZh ? '打开 Discord' : 'Open Discord',
    official: isKo ? '공식 웹사이트: discord.com' : isJa ? '公式サイト: discord.com' : isZh ? '官方网站：discord.com' : 'Official website: discord.com',
  }

  function openDiscord() {
    window.open('https://discord.com/app', '_blank', 'noopener,noreferrer')
  }

  return (
    <main className="flex h-full min-h-[320px] flex-col items-center justify-center gap-5 bg-[#313338] p-6 text-center text-white">
      <div aria-hidden="true" className="flex h-20 w-20 items-center justify-center rounded-3xl bg-[#5865F2] text-4xl font-black shadow-lg">
        <svg viewBox="0 0 24 24" className="h-12 w-12" fill="currentColor">
          <path d="M19.7 5.3A18.4 18.4 0 0 0 15.2 4l-.6 1.2a16.8 16.8 0 0 0-5.2 0L8.8 4a18.4 18.4 0 0 0-4.5 1.3C1.5 9.5.7 13.6 1.1 17.6a18.5 18.5 0 0 0 5.5 2.8l1.2-2a12 12 0 0 1-1.9-.9l.5-.4c3.7 1.7 7.7 1.7 11.3 0l.5.4a12 12 0 0 1-1.9.9l1.2 2a18.5 18.5 0 0 0 5.5-2.8c.5-4.6-.8-8.7-3.3-12.3ZM8.6 14.8c-1.1 0-2-1-2-2.2s.9-2.2 2-2.2 2 1 2 2.2-.9 2.2-2 2.2Zm6.8 0c-1.1 0-2-1-2-2.2s.9-2.2 2-2.2 2 1 2 2.2-.9 2.2-2 2.2Z" />
        </svg>
      </div>
      <h1 className="text-2xl font-bold">{labels.title}</h1>
      <p className="max-w-md text-sm leading-6 text-[#dbdee1]">{labels.description}</p>
      <button
        type="button"
        onClick={openDiscord}
        className="rounded-lg bg-[#5865F2] px-6 py-3 font-semibold transition-colors hover:bg-[#4752C4] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
      >
        {labels.button}
      </button>
      <p className="text-xs text-[#b5bac1]">{labels.official}</p>
    </main>
  )
}
