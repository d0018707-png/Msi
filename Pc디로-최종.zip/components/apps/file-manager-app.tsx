'use client'

import { useState } from 'react'
import {
  ChevronLeft,
  ChevronRight,
  Download,
  FileImage,
  FileMusic,
  FileText,
  Folder,
  HardDrive,
  Home,
  Image as ImageIcon,
  Monitor,
  Music,
} from 'lucide-react'
import type { AppId, OsFamily } from '@/lib/os-config'
import type { Translations } from '@/lib/i18n'
import { cn } from '@/lib/utils'

type FolderKey = 'home' | 'desktop' | 'documents' | 'downloads' | 'pictures' | 'music'

interface FileEntry {
  name: string
  type: 'folder' | 'text' | 'image' | 'audio' | 'archive'
  size?: string
  modified: string
  target?: FolderKey
  opens?: AppId
}

const TREE: Record<FolderKey, FileEntry[]> = {
  home: [
    { name: 'Desktop', type: 'folder', target: 'desktop', modified: '2026-10-21' },
    { name: 'Documents', type: 'folder', target: 'documents', modified: '2026-10-25' },
    { name: 'Downloads', type: 'folder', target: 'downloads', modified: '2026-10-26' },
    { name: 'Pictures', type: 'folder', target: 'pictures', modified: '2026-09-30' },
    { name: 'Music', type: 'folder', target: 'music', modified: '2026-08-12' },
  ],
  desktop: [{ name: 'notes.txt', type: 'text', size: '2 KB', modified: '2026-10-27', opens: 'notepad' }],
  documents: [
    { name: 'Project plan.txt', type: 'text', size: '4 KB', modified: '2026-10-24', opens: 'notepad' },
    { name: 'Meeting notes.txt', type: 'text', size: '1 KB', modified: '2026-10-20', opens: 'notepad' },
    { name: 'Budget 2026.txt', type: 'text', size: '12 KB', modified: '2026-10-02', opens: 'notepad' },
  ],
  downloads: [
    { name: 'kolibri.img', type: 'archive', size: '1.4 MB', modified: '2026-10-26', opens: 'vm' },
    { name: 'linux4.iso', type: 'archive', size: '7.4 MB', modified: '2026-10-26', opens: 'vm' },
  ],
  pictures: [
    { name: 'wallpaper-01.png', type: 'image', size: '2.1 MB', modified: '2026-09-30' },
    { name: 'trip-seoul.jpg', type: 'image', size: '3.4 MB', modified: '2026-07-14' },
    { name: 'screenshot.png', type: 'image', size: '640 KB', modified: '2026-10-11' },
  ],
  music: [],
}

const ICON_FOR: Record<FileEntry['type'], { Icon: typeof Folder; color: string }> = {
  folder: { Icon: Folder, color: 'text-amber-500 fill-amber-300' },
  text: { Icon: FileText, color: 'text-sky-600' },
  image: { Icon: FileImage, color: 'text-emerald-600' },
  audio: { Icon: FileMusic, color: 'text-pink-600' },
  archive: { Icon: HardDrive, color: 'text-zinc-600' },
}

interface FileManagerProps {
  os: OsFamily
  strings: Translations
  onOpenApp: (id: AppId) => void
}

export function FileManagerApp({ os, strings, onOpenApp }: FileManagerProps) {
  const [history, setHistory] = useState<FolderKey[]>(['home'])
  const [index, setIndex] = useState(0)
  const [selected, setSelected] = useState<string | null>(null)
  const current = history[index]
  const entries = TREE[current]
  const isMac = os === 'macos'

  const sidebar: { key: FolderKey; Icon: typeof Folder }[] = [
    { key: 'home', Icon: Home },
    { key: 'desktop', Icon: Monitor },
    { key: 'documents', Icon: FileText },
    { key: 'downloads', Icon: Download },
    { key: 'pictures', Icon: ImageIcon },
    { key: 'music', Icon: Music },
  ]

  function navigate(key: FolderKey) {
    if (key === current) return
    const next = [...history.slice(0, index + 1), key]
    setHistory(next)
    setIndex(next.length - 1)
    setSelected(null)
  }

  function openEntry(entry: FileEntry) {
    if (entry.target) navigate(entry.target)
    else if (entry.opens) onOpenApp(entry.opens)
  }

  return (
    <div className="flex h-full flex-col bg-white text-sm">
      <div className="flex items-center gap-1 border-b border-zinc-200 bg-zinc-50 px-2 py-1.5">
        <button
          type="button"
          aria-label="Back"
          disabled={index === 0}
          onClick={() => setIndex((i) => i - 1)}
          className="rounded p-1 text-zinc-600 hover:bg-zinc-200 disabled:opacity-30"
        >
          <ChevronLeft className="size-4" />
        </button>
        <button
          type="button"
          aria-label="Forward"
          disabled={index >= history.length - 1}
          onClick={() => setIndex((i) => i + 1)}
          className="rounded p-1 text-zinc-600 hover:bg-zinc-200 disabled:opacity-30"
        >
          <ChevronRight className="size-4" />
        </button>
        <div
          className={cn(
            'ml-1 flex-1 truncate border border-zinc-200 bg-white px-3 py-1 text-xs text-zinc-600',
            isMac ? 'rounded-md text-center font-semibold' : 'rounded',
          )}
        >
          {isMac ? strings[current] : `${strings.home} › ${current === 'home' ? '' : strings[current]}`}
        </div>
      </div>
      <div className="flex min-h-0 flex-1">
        <nav
          aria-label={strings.apps.files}
          className={cn(
            'hidden w-44 shrink-0 flex-col gap-0.5 overflow-y-auto border-r border-zinc-200 p-2 sm:flex',
            isMac ? 'bg-zinc-100/80' : 'bg-white',
          )}
        >
          {sidebar.map(({ key, Icon }) => (
            <button
              key={key}
              type="button"
              onClick={() => navigate(key)}
              aria-current={current === key ? 'page' : undefined}
              className={cn(
                'flex items-center gap-2 rounded-md px-2 py-1.5 text-left text-[13px] text-zinc-700 hover:bg-zinc-200/70',
                current === key && (isMac ? 'bg-zinc-300/70' : 'bg-sky-100 text-sky-900'),
              )}
            >
              <Icon className={cn('size-4', isMac ? 'text-sky-600' : 'text-zinc-500')} />
              {strings[key]}
            </button>
          ))}
        </nav>
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="grid grid-cols-[1fr_auto] gap-4 border-b border-zinc-100 px-4 py-1.5 text-[11px] font-medium text-zinc-500 sm:grid-cols-[1fr_7rem_5rem]">
            <span>{strings.name}</span>
            <span className="hidden sm:block">{strings.modified}</span>
            <span className="text-right">{strings.size}</span>
          </div>
          <ul className="min-h-0 flex-1 overflow-y-auto p-1">
            {entries.length === 0 && <li className="p-6 text-center text-zinc-400">{strings.emptyFolder}</li>}
            {entries.map((entry) => {
              const { Icon, color } = ICON_FOR[entry.type]
              const label = entry.target ? strings[entry.target] : entry.name
              return (
                <li key={entry.name}>
                  <button
                    type="button"
                    onClick={() => setSelected(entry.name)}
                    onDoubleClick={() => openEntry(entry)}
                    onKeyDown={(e) => e.key === 'Enter' && openEntry(entry)}
                    className={cn(
                      'grid w-full grid-cols-[1fr_auto] items-center gap-4 rounded px-3 py-1.5 text-left text-[13px] text-zinc-800 hover:bg-zinc-100 sm:grid-cols-[1fr_7rem_5rem]',
                      selected === entry.name && (isMac ? 'bg-sky-500 text-white hover:bg-sky-500' : 'bg-sky-100'),
                    )}
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      <Icon className={cn('size-4 shrink-0', selected === entry.name && isMac ? 'text-white' : color)} />
                      <span className="truncate">{label}</span>
                    </span>
                    <span className="hidden text-xs opacity-70 sm:block">{entry.modified}</span>
                    <span className="text-right text-xs opacity-70">{entry.size ?? '—'}</span>
                  </button>
                </li>
              )
            })}
          </ul>
          <div className="border-t border-zinc-100 px-4 py-1 text-[11px] text-zinc-500">
            {entries.length}
            {strings.items}
          </div>
        </div>
      </div>
    </div>
  )
}
