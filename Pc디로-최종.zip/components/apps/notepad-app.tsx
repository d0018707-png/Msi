'use client'

import type { OsFamily } from '@/lib/os-config'
import type { Translations } from '@/lib/i18n'
import { cn } from '@/lib/utils'

interface NotepadAppProps {
  os: OsFamily
  strings: Translations
  value: string
  onChange: (value: string) => void
}

export function NotepadApp({ os, strings, value, onChange }: NotepadAppProps) {
  const lines = value ? value.split('\n').length : 0
  const isMac = os === 'macos'
  return (
    <div className="flex h-full flex-col bg-white">
      <div
        className={cn(
          'flex items-center gap-1 border-b border-zinc-200 px-2 py-1 text-xs text-zinc-600',
          isMac && 'bg-zinc-50',
        )}
      >
        {[strings.menuFile, strings.menuEdit, strings.menuView].map((m) => (
          <span key={m} className="rounded px-2 py-1 hover:bg-zinc-100">
            {m}
          </span>
        ))}
        <button
          type="button"
          onClick={() => onChange('')}
          className="ml-auto rounded px-2 py-1 hover:bg-zinc-100 focus-visible:outline-2 focus-visible:outline-sky-500"
        >
          {strings.clear}
        </button>
      </div>
      <label htmlFor="notepad-text" className="sr-only">
        {strings.apps.notepad}
      </label>
      <textarea
        id="notepad-text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={strings.notepadPlaceholder}
        spellCheck={false}
        className={cn(
          'min-h-0 flex-1 resize-none p-4 text-sm leading-relaxed text-zinc-900 outline-none placeholder:text-zinc-400',
          isMac ? 'font-sans' : 'font-mono',
        )}
      />
      <div className="flex items-center justify-between border-t border-zinc-200 bg-zinc-50 px-3 py-1 text-[11px] text-zinc-500">
        <span>
          {lines}
          {strings.lines} · {value.length}
          {strings.chars}
        </span>
        <span>{strings.saved} · UTF-8</span>
      </div>
    </div>
  )
}
