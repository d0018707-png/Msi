'use client'

import { useCallback, useEffect, useState } from 'react'
import { ExternalLink, Gamepad2, RotateCcw, Trophy, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react'
import type { Language } from '@/lib/os-config'

const COPY = {
  ko: { title: 'DIAI 플레이 월드', subtitle: '브라우저 안에서 즐기는 미니 장애물 게임', play: '미니 게임 시작', restart: '다시 시작', score: '코인', help: '방향키 또는 아래 버튼으로 움직여 코인을 모으세요.', official: 'Roblox 공식 사이트 열기', note: '이 화면은 사이트 안에서 플레이 가능한 데모 게임입니다. 실제 Roblox 계정/게임 실행은 공식 Roblox 서비스에서 진행됩니다.' },
  en: { title: 'DIAI Play World', subtitle: 'A mini obstacle game inside your browser', play: 'Start mini game', restart: 'Restart', score: 'Coins', help: 'Use arrow keys or the buttons to collect coins.', official: 'Open official Roblox', note: 'This is a playable demo inside the website. Actual Roblox account and game launching require the official Roblox service.' },
  ja: { title: 'DIAI プレイワールド', subtitle: 'ブラウザー内で遊べるミニ障害物ゲーム', play: 'ミニゲーム開始', restart: 'やり直す', score: 'コイン', help: '矢印キーまたは下のボタンでコインを集めてください。', official: 'Roblox公式サイトを開く', note: 'これはサイト内で遊べるデモです。実際のRobloxアカウントやゲームの起動は公式サービスが必要です。' },
} as const

export function RobloxApp({ language }: { language: Language }) {
  const c = COPY[language]
  const [player, setPlayer] = useState({ x: 12, y: 78 })
  const [coin, setCoin] = useState({ x: 72, y: 30 })
  const [score, setScore] = useState(0)
  const [started, setStarted] = useState(false)

  const move = useCallback((dx: number, dy: number) => {
    if (!started) setStarted(true)
    const next = { x: Math.max(3, Math.min(92, player.x + dx)), y: Math.max(8, Math.min(88, player.y + dy)) }
    setPlayer(next)
    if (Math.abs(next.x - coin.x) < 8 && Math.abs(next.y - coin.y) < 10) {
      setScore((s) => s + 1)
      setCoin({ x: 10 + Math.random() * 78, y: 15 + Math.random() * 65 })
    }
  }, [started, player, coin])

  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      const d: Record<string, [number, number]> = {
        ArrowLeft: [-4, 0], a: [-4, 0], ArrowRight: [4, 0], d: [4, 0],
        ArrowUp: [0, -5], w: [0, -5], ArrowDown: [0, 5], s: [0, 5],
      }
      const delta = d[e.key]
      if (delta) { e.preventDefault(); move(delta[0], delta[1]) }
    }
    window.addEventListener('keydown', key)
    return () => window.removeEventListener('keydown', key)
  }, [move])

  const reset = () => { setPlayer({ x: 12, y: 78 }); setCoin({ x: 72, y: 30 }); setScore(0); setStarted(false) }

  return <div className="flex h-full min-h-0 flex-col bg-[#10131d] text-white">
    <header className="flex items-center gap-3 border-b border-white/10 bg-[#191d2b] px-4 py-3">
      <div className="flex size-10 items-center justify-center rounded-xl bg-white text-black"><Gamepad2 /></div>
      <div className="min-w-0 flex-1"><h3 className="font-bold">{c.title}</h3><p className="text-xs text-slate-400">{c.subtitle}</p></div>
      <div className="flex items-center gap-1 rounded-lg bg-amber-400/15 px-3 py-2 text-amber-300"><Trophy size={16}/><b>{score}</b><span className="hidden text-xs sm:inline">{c.score}</span></div>
    </header>
    <div className="flex min-h-0 flex-1 flex-col gap-3 overflow-auto p-3 sm:p-4">
      <div className="relative min-h-[210px] flex-1 overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-b from-sky-400 via-sky-300 to-emerald-300" tabIndex={0} aria-label="Playable mini game area">
        <div className="absolute inset-x-0 bottom-0 h-[22%] bg-gradient-to-b from-green-500 to-green-700"/>
        <div className="absolute left-[8%] top-[12%] size-12 rounded-full bg-yellow-100/80 blur-[1px]"/>
        <div className="absolute left-[18%] top-[28%] h-4 w-20 rounded-full bg-white/50"/>
        <div className="absolute left-[58%] top-[17%] h-3 w-28 rounded-full bg-white/50"/>
        <div className="absolute left-[36%] bottom-[22%] h-3 w-[28%] rounded-full bg-amber-800 shadow-lg"/>
        <div className="absolute bottom-[22%] left-[69%] h-3 w-[18%] rounded-full bg-amber-800 shadow-lg"/>
        <div className="absolute z-10 flex size-7 items-center justify-center rounded-full border-4 border-yellow-100 bg-yellow-400 text-yellow-900 shadow-[0_0_20px_#fde047]" style={{left:`${coin.x}%`,top:`${coin.y}%`}}>★</div>
        <div className="absolute z-20 flex h-10 w-7 items-center justify-center rounded-md border-2 border-white/70 bg-violet-600 shadow-xl transition-all duration-100" style={{left:`${player.x}%`,top:`${player.y}%`}}>
          <span className="absolute -top-3 size-5 rounded-full border-2 border-orange-100 bg-orange-300"/>
          <span className="text-xs">●</span>
        </div>
        {!started && <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-slate-950/35 p-4 text-center backdrop-blur-[2px]"><Gamepad2 size={34}/><b className="mt-2 text-lg">{c.play}</b><span className="mt-1 text-xs text-white/80">{c.help}</span></div>}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-xs leading-relaxed text-slate-400">{c.help}</p>
        <div className="grid grid-cols-3 gap-1">
          <span/><button onClick={() => move(0,-7)} aria-label="Up" className="rounded-lg bg-white/10 p-2 hover:bg-white/20"><ArrowUp size={18}/></button><span/>
          <button onClick={() => move(-5,0)} aria-label="Left" className="rounded-lg bg-white/10 p-2 hover:bg-white/20"><ArrowLeft size={18}/></button>
          <button onClick={() => move(0,7)} aria-label="Down" className="rounded-lg bg-white/10 p-2 hover:bg-white/20"><ArrowDown size={18}/></button>
          <button onClick={() => move(5,0)} aria-label="Right" className="rounded-lg bg-white/10 p-2 hover:bg-white/20"><ArrowRight size={18}/></button>
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        <button onClick={reset} className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-sm hover:bg-white/10"><RotateCcw size={15}/>{c.restart}</button>
        <a href="https://www.roblox.com/" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-sm font-semibold text-black hover:bg-slate-200">{c.official}<ExternalLink size={14}/></a>
      </div>
      <p className="text-[11px] leading-relaxed text-slate-500">{c.note}</p>
    </div>
  </div>
}
