'use client'

import { useEffect, useState } from 'react'
import { Blocks, Box, Circle, Cylinder, Download, ExternalLink, MousePointer2, RotateCcw, Trash2 } from 'lucide-react'
import type { Language } from '@/lib/os-config'

type Item = { id: number; type: 'block' | 'ball' | 'cylinder'; x: number; y: number; color: string }
const COPY = {
  ko: { title: 'Roblox Studio — 웹 씬 편집기', subtitle: '간단한 월드를 만들어 보세요', insert: '개체 추가', block: '블록', ball: '구', cylinder: '원기둥', clear: '씬 초기화', save: '프로젝트 내보내기', official: '공식 Studio 안내', select: '장면을 눌러 개체를 선택하고 드래그하세요.', note: '이것은 사이트 안에서 작동하는 간단한 Studio 스타일 편집기입니다. Roblox Studio의 실제 엔진이나 .rbxl 프로젝트를 완전히 대체하지 않습니다.' },
  en: { title: 'Roblox Studio — Web Scene Editor', subtitle: 'Build a simple world', insert: 'Insert object', block: 'Block', ball: 'Sphere', cylinder: 'Cylinder', clear: 'Clear scene', save: 'Export project', official: 'Official Studio info', select: 'Click an object to select it, then drag it around.', note: 'This is a lightweight Studio-style editor inside the website. It does not replace the real Roblox Studio engine or fully export .rbxl projects.' },
  ja: { title: 'Roblox Studio — Webシーンエディター', subtitle: '簡単なワールドを作成', insert: 'オブジェクト追加', block: 'ブロック', ball: '球', cylinder: '円柱', clear: 'シーンをクリア', save: 'プロジェクトを書き出す', official: '公式Studio情報', select: 'オブジェクトをクリックして選択し、ドラッグして移動します。', note: 'これはサイト内の簡易Studio風エディターです。実際のRoblox Studioエンジンや.rbxlファイルを完全に置き換えるものではありません。' },
} as const
const COLORS = ['#60a5fa', '#f87171', '#fbbf24', '#34d399', '#c084fc', '#f472b6']

export function RobloxStudioApp({ language }: { language: Language }) {
  const c = COPY[language]
  const [items, setItems] = useState<Item[]>([])
  const [selected, setSelected] = useState<number | null>(null)
  const [colorIndex, setColorIndex] = useState(0)

  useEffect(() => {
    try {
      const saved = localStorage.getItem('desktop-os-roblox-studio')
      if (saved) setItems(JSON.parse(saved) as Item[])
    } catch {}
  }, [])
  useEffect(() => {
    try { localStorage.setItem('desktop-os-roblox-studio', JSON.stringify(items)) } catch {}
  }, [items])

  const add = (type: Item['type']) => {
    const id = Date.now() + Math.floor(Math.random() * 1000)
    setItems((old) => [...old, { id, type, x: 20 + (old.length * 11) % 60, y: 28 + (old.length * 9) % 45, color: COLORS[colorIndex % COLORS.length] }])
    setSelected(id)
  }
  const updateSelected = (patch: Partial<Item>) => setItems((old) => old.map((item) => item.id === selected ? { ...item, ...patch } : item))
  const exportProject = () => {
    const blob = new Blob([JSON.stringify({ project: 'DIAI Roblox Studio Web Demo', items }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'diai-studio-scene.json'; a.click(); URL.revokeObjectURL(url)
  }

  return <div className="flex h-full min-h-0 flex-col bg-[#20232b] text-zinc-100">
    <header className="flex items-center gap-2 border-b border-black/30 bg-[#30343d] px-3 py-2">
      <div className="rounded-lg bg-sky-500 p-2"><Blocks size={18}/></div>
      <div className="min-w-0 flex-1"><h3 className="truncate text-sm font-bold">{c.title}</h3><p className="text-[11px] text-zinc-400">{c.subtitle}</p></div>
      <button title={c.clear} onClick={() => {setItems([]);setSelected(null)}} className="rounded-md p-2 hover:bg-white/10"><Trash2 size={16}/></button>
      <button title={c.save} onClick={exportProject} className="rounded-md p-2 hover:bg-white/10"><Download size={16}/></button>
    </header>
    <div className="flex min-h-0 flex-1">
      <aside className="w-14 shrink-0 border-r border-black/30 bg-[#282c34] p-1 sm:w-40 sm:p-3">
        <p className="mb-2 hidden text-[10px] font-bold uppercase tracking-wider text-zinc-400 sm:block">{c.insert}</p>
        <div className="flex flex-col gap-1">
          <button onClick={() => add('block')} className="flex items-center gap-2 rounded-md p-2 text-left text-xs hover:bg-white/10"><Box size={17}/><span className="hidden sm:inline">{c.block}</span></button>
          <button onClick={() => add('ball')} className="flex items-center gap-2 rounded-md p-2 text-left text-xs hover:bg-white/10"><Circle size={17}/><span className="hidden sm:inline">{c.ball}</span></button>
          <button onClick={() => add('cylinder')} className="flex items-center gap-2 rounded-md p-2 text-left text-xs hover:bg-white/10"><Cylinder size={17}/><span className="hidden sm:inline">{c.cylinder}</span></button>
        </div>
        <div className="my-3 border-t border-white/10"/>
        <p className="mb-2 hidden text-[10px] font-bold uppercase tracking-wider text-zinc-400 sm:block">Properties</p>
        <div className="flex flex-wrap gap-1">
          {COLORS.map((color, i) => <button key={color} aria-label={`Color ${i+1}`} onClick={() => {setColorIndex(i);updateSelected({color})}} className="size-5 rounded-full border border-white/30" style={{backgroundColor:color}}/>)}
        </div>
        {selected !== null && <button onClick={() => {setItems((old) => old.filter((item) => item.id !== selected));setSelected(null)}} className="mt-3 flex items-center gap-1 rounded-md p-2 text-xs text-red-300 hover:bg-red-500/10"><Trash2 size={14}/><span className="hidden sm:inline">Delete</span></button>}
      </aside>
      <main className="relative min-w-0 flex-1 overflow-hidden bg-[#171a21]" style={{backgroundImage:'linear-gradient(#ffffff0b 1px, transparent 1px),linear-gradient(90deg,#ffffff0b 1px, transparent 1px)',backgroundSize:'22px 22px'}}>
        <div className="absolute inset-x-[8%] bottom-[12%] h-[14%] skew-x-[-15deg] rounded-md border border-emerald-300/40 bg-emerald-500/20"/>
        <div className="absolute left-3 top-3 flex items-center gap-1 text-[10px] text-zinc-500"><MousePointer2 size={12}/> {c.select}</div>
        {items.map((item) => <button key={item.id} onClick={() => setSelected(item.id)} draggable onDragEnd={(e) => {const r=e.currentTarget.parentElement?.getBoundingClientRect();if(r){setItems(old=>old.map(it=>it.id===item.id?{...it,x:Math.max(3,Math.min(90,((e.clientX-r.left)/r.width)*100)),y:Math.max(8,Math.min(80,((e.clientY-r.top)/r.height)*100))}:it))}}} className={`absolute flex cursor-grab items-center justify-center shadow-lg ${item.type==='ball'?'rounded-full':item.type==='cylinder'?'rounded-[40%]':'rounded-sm'} ${selected===item.id?'ring-2 ring-white ring-offset-2 ring-offset-transparent':''}`} style={{left:`${item.x}%`,top:`${item.y}%`,width:item.type==='block'?44:38,height:item.type==='block'?44:38,backgroundColor:item.color,transform:'translate(-50%,-50%)'}} aria-label={`Select ${item.type}`}/>)}
        {items.length===0 && <div className="absolute inset-0 flex items-center justify-center p-5 text-center text-xs text-zinc-500"><div><Blocks size={28} className="mx-auto mb-2 opacity-60"/>왼쪽에서 개체를 추가해 월드를 만드세요</div></div>}
      </main>
    </div>
    <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-black/30 bg-[#30343d] px-3 py-2 text-[10px] text-zinc-400">
      <span>{items.length} objects · {selected === null ? 'No selection' : `Selected: ${items.find(x=>x.id===selected)?.type ?? ''}`}</span>
      <a href="https://create.roblox.com/" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-md bg-white/10 px-2 py-1 text-zinc-200 hover:bg-white/20">{c.official}<ExternalLink size={12}/></a>
      <span className="w-full leading-relaxed sm:w-auto">{c.note}</span>
    </footer>
  </div>
}
