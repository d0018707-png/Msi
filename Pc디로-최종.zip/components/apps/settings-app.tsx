'use client'

import { useState } from 'react'
import { Check, Globe, Info, Monitor, RotateCcw } from 'lucide-react'
import { LANGUAGES, OS_VERSIONS, versionLabel, type Language, type OsConfig } from '@/lib/os-config'
import type { Translations } from '@/lib/i18n'
import { cn } from '@/lib/utils'

interface SettingsAppProps {
  config: OsConfig
  strings: Translations
  onApply: (config: OsConfig) => void
  onChangeOs: () => void
}

type Section = 'system' | 'language' | 'about'

export function SettingsApp({ config, strings, onApply, onChangeOs }: SettingsAppProps) {
  const [section, setSection] = useState<Section>('system')
  const [version, setVersion] = useState(config.version)
  const [language, setLanguage] = useState<Language>(config.language)
  const isMac = config.os === 'macos'
  const dirty = version !== config.version || language !== config.language

  const nav: { key: Section; label: string; Icon: typeof Monitor }[] = [
    { key: 'system', label: strings.system, Icon: Monitor },
    { key: 'language', label: strings.languageLabel, Icon: Globe },
    { key: 'about', label: strings.about, Icon: Info },
  ]

  return (
    <div className={cn('flex h-full flex-col text-sm text-zinc-800 sm:flex-row', isMac ? 'bg-zinc-50' : 'bg-zinc-100')}>
      <nav
        aria-label={strings.apps.settings}
        className={cn(
          'flex shrink-0 gap-1 overflow-x-auto border-b border-zinc-200 p-2 sm:w-48 sm:flex-col sm:border-r sm:border-b-0',
          isMac ? 'bg-zinc-100' : 'bg-zinc-100',
        )}
      >
        <div className="mb-2 hidden items-center gap-2 px-2 py-2 sm:flex">
          <span className="flex size-9 items-center justify-center rounded-full bg-sky-600 text-sm font-semibold text-white">
            G
          </span>
          <span className="text-xs font-medium">{strings.user}</span>
        </div>
        {nav.map(({ key, label, Icon }) => (
          <button
            key={key}
            type="button"
            onClick={() => setSection(key)}
            aria-current={section === key ? 'page' : undefined}
            className={cn(
              'flex shrink-0 items-center gap-2 rounded-md px-3 py-1.5 text-left text-[13px] hover:bg-zinc-200',
              section === key && (isMac ? 'bg-sky-500 text-white hover:bg-sky-500' : 'bg-white shadow-sm'),
            )}
          >
            <Icon className="size-4" />
            {label}
          </button>
        ))}
      </nav>

      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto p-5">
        <h3 className="text-xl font-semibold">{nav.find((n) => n.key === section)?.label}</h3>

        <div className="mt-4 rounded-lg border border-zinc-200 bg-white p-4">
          <p className="text-[11px] font-medium uppercase tracking-wide text-zinc-500">{strings.current}</p>
          <dl className="mt-2 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-[13px]">
            <dt className="text-zinc-500">{strings.osLabel}</dt>
            <dd className="font-medium">{isMac ? 'macOS' : 'Windows'}</dd>
            <dt className="text-zinc-500">{strings.versionLabel}</dt>
            <dd className="font-medium">{versionLabel(config.os, config.version)}</dd>
            <dt className="text-zinc-500">{strings.languageLabel}</dt>
            <dd className="font-medium">{LANGUAGES.find((l) => l.id === config.language)?.native}</dd>
          </dl>
        </div>

        {section === 'system' && (
          <fieldset className="mt-4">
            <legend className="mb-2 text-[13px] font-medium">{strings.versionLabel}</legend>
            <div className="flex flex-col gap-1.5">
              {OS_VERSIONS[config.os].map((v) => (
                <label
                  key={v.id}
                  className={cn(
                    'flex cursor-pointer items-center justify-between rounded-lg border bg-white px-4 py-2.5',
                    version === v.id ? 'border-sky-500 ring-1 ring-sky-500' : 'border-zinc-200 hover:border-zinc-300',
                  )}
                >
                  <input
                    type="radio"
                    name="settings-version"
                    value={v.id}
                    checked={version === v.id}
                    onChange={() => setVersion(v.id)}
                    className="sr-only"
                  />
                  <span>
                    <span className="font-medium">{v.label}</span>
                    <span className="ml-2 text-xs text-zinc-500">
                      {v.codename} · {v.year}
                    </span>
                  </span>
                  {version === v.id && <Check className="size-4 text-sky-600" />}
                </label>
              ))}
            </div>
          </fieldset>
        )}

        {section === 'language' && (
          <fieldset className="mt-4">
            <legend className="mb-2 text-[13px] font-medium">{strings.languageLabel}</legend>
            <div className="flex flex-col gap-1.5">
              {LANGUAGES.map((l) => (
                <label
                  key={l.id}
                  className={cn(
                    'flex cursor-pointer items-center justify-between rounded-lg border bg-white px-4 py-2.5',
                    language === l.id ? 'border-sky-500 ring-1 ring-sky-500' : 'border-zinc-200 hover:border-zinc-300',
                  )}
                >
                  <input
                    type="radio"
                    name="settings-language"
                    value={l.id}
                    checked={language === l.id}
                    onChange={() => setLanguage(l.id)}
                    className="sr-only"
                  />
                  <span>
                    <span className="font-medium">{l.native}</span>
                    <span className="ml-2 text-xs text-zinc-500">{l.label}</span>
                  </span>
                  {language === l.id && <Check className="size-4 text-sky-600" />}
                </label>
              ))}
            </div>
          </fieldset>
        )}

        {section === 'about' && (
          <div className="mt-4 rounded-lg border border-zinc-200 bg-white p-4 text-[13px] leading-relaxed text-zinc-600">
            <p>{strings.simulated}</p>
            <p className="mt-1">User agent: {typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 80) : ''}</p>
            <button
              type="button"
              onClick={onChangeOs}
              className="mt-3 rounded-md border border-zinc-300 px-3 py-1.5 text-[13px] font-medium hover:bg-zinc-50"
            >
              {strings.changeOs}
            </button>
          </div>
        )}

        {section !== 'about' && (
          <div className="mt-auto flex flex-col gap-2 pt-5 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs text-zinc-500">{strings.settingsDesc}</p>
            <button
              type="button"
              disabled={!dirty}
              onClick={() => onApply({ os: config.os, version, language })}
              className={cn(
                'flex items-center justify-center gap-2 px-4 py-2 text-[13px] font-medium text-white disabled:opacity-40',
                isMac ? 'rounded-lg bg-sky-500 hover:bg-sky-600' : 'rounded bg-sky-700 hover:bg-sky-800',
              )}
            >
              <RotateCcw className="size-3.5" />
              {strings.applyRestart}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
