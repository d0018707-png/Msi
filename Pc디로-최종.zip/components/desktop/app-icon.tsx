import { Calculator, Globe, Compass, Cpu, FileText, Folder, MessagesSquare, Settings, Gamepad2, Blocks } from 'lucide-react'
import type { AppId, OsFamily } from '@/lib/os-config'
import { cn } from '@/lib/utils'

const ICONS: Record<AppId, { Icon: typeof Folder; className: string }> = {
  files: { Icon: Folder, className: 'bg-gradient-to-b from-amber-300 to-amber-500 text-amber-950' },
  notepad: { Icon: FileText, className: 'bg-gradient-to-b from-white to-zinc-200 text-zinc-700' },
  calculator: { Icon: Calculator, className: 'bg-gradient-to-b from-zinc-600 to-zinc-800 text-orange-300' },
  settings: { Icon: Settings, className: 'bg-gradient-to-b from-zinc-300 to-zinc-500 text-zinc-800' },
  browser: { Icon: Compass, className: 'bg-gradient-to-b from-sky-400 to-blue-600 text-white' },
  chrome: { Icon: Globe, className: 'bg-gradient-to-br from-red-500 via-amber-400 to-emerald-500 text-white' },
  discord: { Icon: MessagesSquare, className: 'bg-gradient-to-b from-indigo-400 to-indigo-600 text-white' },
  roblox: { Icon: Gamepad2, className: 'bg-gradient-to-b from-zinc-100 to-zinc-300 text-zinc-900' },
  robloxStudio: { Icon: Blocks, className: 'bg-gradient-to-b from-sky-400 to-blue-700 text-white' },
  vm: { Icon: Cpu, className: 'bg-gradient-to-b from-emerald-400 to-teal-600 text-white' },
}

export function AppIcon({ id, os, size = 48 }: { id: AppId; os: OsFamily; size?: number }) {
  const { Icon, className } = ICONS[id]
  return (
    <span
      aria-hidden="true"
      className={cn(
        'flex shrink-0 items-center justify-center shadow-md ring-1 ring-black/10',
        os === 'macos' ? 'rounded-[24%]' : 'rounded-[18%]',
        className,
      )}
      style={{ width: size, height: size }}
    >
      <Icon style={{ width: size * 0.55, height: size * 0.55 }} strokeWidth={1.8} />
    </span>
  )
}
