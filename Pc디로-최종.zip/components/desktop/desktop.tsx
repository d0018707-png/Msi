'use client'

import { useEffect, useRef, useState } from 'react'
import { APP_IDS, type AppId, type OsConfig } from '@/lib/os-config'
import { t } from '@/lib/i18n'
import { useOsStore } from '@/lib/os-store'
import { useWindowManager } from '@/lib/use-window-manager'
import { cn } from '@/lib/utils'
import { AppIcon } from './app-icon'
import { WindowFrame } from './window-frame'
import { WindowsShell } from './windows-shell'
import { MacShell } from './mac-shell'
import { FileManagerApp } from '@/components/apps/file-manager-app'
import { NotepadApp } from '@/components/apps/notepad-app'
import { CalculatorApp } from '@/components/apps/calculator-app'
import { SettingsApp } from '@/components/apps/settings-app'
import { BrowserApp } from '@/components/apps/browser-app'
import { VmLauncher } from '@/components/vm/vm-launcher'
import { ChromeApp } from '@/components/apps/chrome-app'
import { DiscordApp } from '@/components/apps/discord-app'
import { RobloxApp } from '@/components/apps/roblox-app'
import { RobloxStudioApp } from '@/components/apps/roblox-studio-app'
import { SitePortal } from '@/components/site-portal'

export function Desktop({ config }: { config: OsConfig }) {
  const { boot, shutDown, notes, setNotes } = useOsStore()
  const strings = t(config.language)
  const wm = useWindowManager()
  const areaRef = useRef<HTMLDivElement>(null)
  const [bounds, setBounds] = useState({ width: 1024, height: 700 })
  const [selectedIcon, setSelectedIcon] = useState<AppId | null>(null)
  const [activityCount, setActivityCount] = useState(0)

  // Persistent usage history is stored on this browser/device (not synced to a server).
  useEffect(() => {
    try {
      const raw = localStorage.getItem('webos-activity-log')
      const list = raw ? JSON.parse(raw) : []
      setActivityCount(Array.isArray(list) ? list.length : 0)
    } catch { setActivityCount(0) }
  }, [])

  function recordActivity(action: string, detail: string) {
    try {
      const key = 'webos-activity-log'
      const previous = JSON.parse(localStorage.getItem(key) || '[]')
      const next = [...(Array.isArray(previous) ? previous : []), {
        action, detail, os: config.os, version: config.version, language: config.language,
        at: new Date().toISOString()
      }].slice(-500)
      localStorage.setItem(key, JSON.stringify(next))
      setActivityCount(next.length)
    } catch { /* private browsing/storage restrictions: keep app usable */ }
  }
  const isMac = config.os === 'macos'

  useEffect(() => {
    const el = areaRef.current
    if (!el) return
    const observer = new ResizeObserver(([entry]) =>
      setBounds({ width: entry.contentRect.width, height: entry.contentRect.height }),
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    wm.fitToBounds(bounds)
  }, [bounds, wm.fitToBounds])

  const launch = (id: AppId) => {
    wm.open(id, bounds)
    recordActivity('app-open', id)
  }

  function renderApp(id: AppId) {
    switch (id) {
      case 'files':
        return <FileManagerApp os={config.os} strings={strings} onOpenApp={launch} />
      case 'notepad':
        return <NotepadApp os={config.os} strings={strings} value={notes} onChange={setNotes} />
      case 'calculator':
        return <CalculatorApp os={config.os} label={strings.apps.calculator} />
      case 'settings':
        return <SettingsApp config={config} strings={strings} onApply={boot} onChangeOs={shutDown} />
      case 'browser':
        return <BrowserApp os={config.os} strings={strings} />
      case 'chrome':
        return <ChromeApp language={config.language} />
      case 'discord':
        return <DiscordApp language={config.language} />
      case 'roblox':
        return <RobloxApp language={config.language} />
      case 'robloxStudio':
        return <RobloxStudioApp language={config.language} />
      case 'vm':
        return <VmLauncher language={config.language} active={wm.activeId === 'vm'} />
    }
  }

  return (
    <div
      lang={config.language}
      className="relative h-[100svh] min-h-[360px] w-full overflow-hidden bg-zinc-900 bg-cover bg-center animate-in fade-in duration-700"
      style={{ backgroundImage: `url(/wallpapers/${isMac ? 'macos' : 'windows'}.png)` }}
    >
      <div
        ref={areaRef}
        className={cn('absolute inset-x-0 min-h-0', isMac ? 'top-7 bottom-0' : 'top-0 bottom-12')}
        onPointerDown={(e) => e.target === e.currentTarget && setSelectedIcon(null)}
      >
        <ul
          aria-label={strings.desktop}
          className={cn(
            'absolute flex flex-col flex-wrap gap-1 p-2',
            isMac ? 'right-0 top-0 max-h-[calc(100%-5rem)] items-end' : 'left-0 top-0 max-h-full',
          )}
        >
          {APP_IDS.map((id) => (
            <li key={id}>
              <button
                type="button"
                onClick={() => {
                  setSelectedIcon(id)
                  launch(id)
                }}
                className={cn(
                  'flex w-20 flex-col items-center gap-1 rounded-md p-1.5 text-center outline-none focus-visible:ring-2 focus-visible:ring-white/70',
                  isMac ? 'hover:bg-black/15' : 'hover:bg-white/15',
                  selectedIcon === id && (isMac ? 'bg-black/25' : 'bg-white/25'),
                )}
              >
                <AppIcon id={id} os={config.os} size={44} />
                <span
                  className={cn(
                    'line-clamp-2 text-[11px] leading-tight text-white [text-shadow:0_1px_3px_rgb(0_0_0/0.8)]',
                    isMac && selectedIcon === id && 'rounded bg-sky-600 px-1',
                  )}
                >
                  {strings.apps[id]}
                </span>
              </button>
            </li>
          ))}
        </ul>

        {wm.windows.map((win) => (
          <WindowFrame
            key={win.id}
            win={win}
            os={config.os}
            title={strings.apps[win.id]}
            active={wm.activeId === win.id}
            strings={strings}
            bounds={bounds}
            onFocus={() => wm.activeId !== win.id && wm.focus(win.id)}
            onClose={() => wm.close(win.id)}
            onMinimize={() => wm.minimize(win.id)}
            onToggleMaximize={() => wm.toggleMaximize(win.id)}
            onMove={(x, y) => wm.move(win.id, x, y)}
          >
            {renderApp(win.id)}
          </WindowFrame>
        ))}
      </div>

      {isMac ? (
        <MacShell
          config={config}
          strings={strings}
          wm={wm}
          onLaunch={launch}
          onShutDown={shutDown}
          onRestart={() => boot({ ...config })}
        />
      ) : (
        <WindowsShell
          config={config}
          strings={strings}
          wm={wm}
          onLaunch={launch}
          onShutDown={shutDown}
          onRestart={() => boot({ ...config })}
        />
      )}
    </div>
  )
}
