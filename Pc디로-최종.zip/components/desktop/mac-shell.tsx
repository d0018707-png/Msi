'use client'

import { useEffect, useRef, useState } from 'react'
import { Battery, Search, Wifi } from 'lucide-react'
import { APP_IDS, type AppId, type OsConfig } from '@/lib/os-config'
import { LOCALE_TAGS, type Translations } from '@/lib/i18n'
import { useClock } from '@/lib/use-clock'
import type { WindowManager } from '@/lib/use-window-manager'
import { cn } from '@/lib/utils'
import { AppIcon } from './app-icon'

interface MacShellProps {
  config: OsConfig
  strings: Translations
  wm: WindowManager
  onLaunch: (id: AppId) => void
  onShutDown: () => void
  onRestart: () => void
}

export function MacShell({ config, strings, wm, onLaunch, onShutDown, onRestart }: MacShellProps) {
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)
  const now = useClock()
  const locale = LOCALE_TAGS[config.language]
  const activeTitle = wm.activeId ? strings.apps[wm.activeId] : strings.finder

  useEffect(() => {
    if (!menuOpen) return
    function onDown(e: PointerEvent) {
      if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false)
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') setMenuOpen(false)
    }
    window.addEventListener('pointerdown', onDown)
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('pointerdown', onDown)
      window.removeEventListener('keydown', onKey)
    }
  }, [menuOpen])

  const systemItems: { label: string; action: () => void; divider?: boolean }[] = [
    { label: strings.aboutThis, action: () => onLaunch('settings') },
    { label: strings.systemSettings, action: () => onLaunch('settings'), divider: true },
    { label: strings.restart, action: onRestart },
    { label: strings.shutDown, action: onShutDown, divider: true },
    { label: strings.logOut, action: onShutDown },
  ]

  return (
    <>
      <header className="absolute inset-x-0 top-0 z-[8000] flex h-7 items-center gap-1 bg-black/25 px-2 text-[13px] text-white backdrop-blur-2xl">
        <div ref={menuRef} className="relative">
          <button
            type="button"
            aria-label="System menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((o) => !o)}
            className={cn('flex h-6 items-center rounded px-2 hover:bg-white/20', menuOpen && 'bg-white/20')}
          >
            <SystemGlyph />
          </button>
          {menuOpen && (
            <div
              role="menu"
              className="absolute left-0 top-7 w-56 rounded-lg border border-white/20 bg-zinc-800/85 p-1 text-zinc-100 shadow-2xl backdrop-blur-2xl animate-in fade-in"
            >
              {systemItems.map((item) => (
                <div key={item.label}>
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      item.action()
                      setMenuOpen(false)
                    }}
                    className="w-full rounded px-3 py-1 text-left text-[13px] hover:bg-sky-500"
                  >
                    {item.label}
                  </button>
                  {item.divider && <div className="mx-2 my-1 h-px bg-white/15" />}
                </div>
              ))}
            </div>
          )}
        </div>
        <span className="px-2 font-semibold">{activeTitle}</span>
        <nav aria-label="Menu bar" className="hidden items-center sm:flex">
          {[strings.menuFile, strings.menuEdit, strings.menuView, strings.menuWindow, strings.menuHelp].map((m) => (
            <span key={m} className="rounded px-2 py-0.5 hover:bg-white/20">
              {m}
            </span>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-3 pr-1">
          <span className="hidden items-center gap-3 sm:flex">
            <Battery className="size-4" />
            <Wifi className="size-3.5" />
            <Search className="size-3.5" />
          </span>
          {now && (
            <time dateTime={now.toISOString()} className="whitespace-nowrap">
              {now.toLocaleDateString(locale, { month: 'short', day: 'numeric', weekday: 'short' })}{' '}
              {now.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })}
            </time>
          )}
        </div>
      </header>

      <nav
        aria-label="Dock"
        className="absolute bottom-2 left-1/2 z-[8000] flex max-w-[calc(100%-1rem)] -translate-x-1/2 items-end gap-1.5 overflow-x-auto rounded-2xl border border-white/25 bg-white/20 px-2 py-1.5 shadow-2xl backdrop-blur-2xl"
      >
        {APP_IDS.map((id) => {
          const win = wm.windows.find((w) => w.id === id)
          return (
            <button
              key={id}
              type="button"
              onClick={() => (win ? wm.focus(id) : onLaunch(id))}
              aria-label={strings.apps[id]}
              title={strings.apps[id]}
              className="group relative flex shrink-0 flex-col items-center transition-transform duration-150 hover:-translate-y-2 hover:scale-110"
            >
              <span className="pointer-events-none absolute -top-9 hidden whitespace-nowrap rounded-md bg-zinc-800/90 px-2 py-0.5 text-xs text-white group-hover:block">
                {strings.apps[id]}
              </span>
              <AppIcon id={id} os="macos" size={44} />
              <span className={cn('mt-0.5 size-1 rounded-full', win ? 'bg-white/90' : 'bg-transparent')} />
            </button>
          )
        })}
      </nav>
    </>
  )
}

function SystemGlyph() {
  return (
    <span aria-hidden="true" className="relative block size-3.5">
      <span className="absolute inset-0 rounded-full border-2 border-white" />
      <span className="absolute left-1/2 top-1/2 size-1 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white" />
    </span>
  )
}
