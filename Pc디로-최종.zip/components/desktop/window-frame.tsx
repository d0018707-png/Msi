'use client'

import { useRef } from 'react'
import { Copy, Minus, Square, X } from 'lucide-react'
import type { OsFamily } from '@/lib/os-config'
import type { Translations } from '@/lib/i18n'
import type { WindowState } from '@/lib/use-window-manager'
import { cn } from '@/lib/utils'
import { AppIcon } from './app-icon'

interface WindowFrameProps {
  win: WindowState
  os: OsFamily
  title: string
  active: boolean
  strings: Translations
  bounds: { width: number; height: number }
  onFocus: () => void
  onClose: () => void
  onMinimize: () => void
  onToggleMaximize: () => void
  onMove: (x: number, y: number) => void
  children: React.ReactNode
}

export function WindowFrame({
  win,
  os,
  title,
  active,
  strings,
  bounds,
  onFocus,
  onClose,
  onMinimize,
  onToggleMaximize,
  onMove,
  children,
}: WindowFrameProps) {
  const drag = useRef<{ dx: number; dy: number; pointerId: number } | null>(null)

  function handlePointerDown(e: React.PointerEvent<HTMLDivElement>) {
    onFocus()
    // Pointer events support mouse, pen, and touch dragging.
    if (win.maximized || (e.pointerType === 'mouse' && e.button !== 0)) return
    if ((e.target as HTMLElement).closest('button')) return
    drag.current = { dx: e.clientX - win.x, dy: e.clientY - win.y, pointerId: e.pointerId }
    e.currentTarget.setPointerCapture(e.pointerId)
  }

  function handlePointerMove(e: React.PointerEvent<HTMLDivElement>) {
    if (!drag.current || drag.current.pointerId !== e.pointerId) return
    const x = Math.min(Math.max(e.clientX - drag.current.dx, -win.width + 120), bounds.width - 120)
    const y = Math.min(Math.max(e.clientY - drag.current.dy, 0), bounds.height - 40)
    onMove(x, y)
  }

  function handlePointerUp(e: React.PointerEvent<HTMLDivElement>) {
    if (drag.current?.pointerId === e.pointerId) drag.current = null
  }

  const style: React.CSSProperties = win.maximized
    ? { left: 0, top: 0, width: '100%', height: '100%', zIndex: win.z }
    : { left: win.x, top: win.y, width: win.width, height: win.height, zIndex: win.z }

  const isMac = os === 'macos'

  return (
    <section
      role="dialog"
      aria-label={title}
      onPointerDown={onFocus}
      className={cn(
        'absolute flex flex-col overflow-hidden border shadow-2xl transition-[opacity,transform] duration-150 animate-in fade-in zoom-in-95',
        win.minimized && 'pointer-events-none scale-90 opacity-0',
        isMac
          ? 'rounded-xl border-black/20 bg-white text-zinc-900'
          : 'rounded-lg border-black/10 bg-white text-zinc-900',
        win.maximized && 'rounded-none',
        !active && 'shadow-lg',
      )}
      style={style}
      aria-hidden={win.minimized}
    >
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onLostPointerCapture={handlePointerUp}
        onDoubleClick={(e) => {
          if (!(e.target as HTMLElement).closest('button')) onToggleMaximize()
        }}
        className={cn(
          'flex h-10 shrink-0 touch-none select-none items-center border-b',
          isMac ? 'gap-3 border-zinc-200 bg-zinc-100 px-3' : 'border-zinc-200 bg-zinc-50 pl-3',
          !active && 'opacity-80',
          !win.maximized && 'cursor-grab active:cursor-grabbing',
        )}
      >
        {isMac ? (
          <>
            <div className="group flex items-center gap-2">
              <MacButton label={strings.close} color="bg-[#ff5f57]" onClick={onClose}>
                <X className="size-2" strokeWidth={3} />
              </MacButton>
              <MacButton label={strings.minimize} color="bg-[#febc2e]" onClick={onMinimize}>
                <Minus className="size-2" strokeWidth={3} />
              </MacButton>
              <MacButton
                label={win.maximized ? strings.restore : strings.maximize}
                color="bg-[#28c840]"
                onClick={onToggleMaximize}
              >
                <Square className="size-1.5" strokeWidth={3} />
              </MacButton>
            </div>
            <h2 className="flex-1 truncate pr-14 text-center text-[13px] font-semibold text-zinc-700">{title}</h2>
          </>
        ) : (
          <>
            <AppIcon id={win.id} os={os} size={16} />
            <h2 className="ml-2 flex-1 truncate text-xs text-zinc-700">{title}</h2>
            <WinButton label={strings.minimize} onClick={onMinimize}>
              <Minus className="size-4" strokeWidth={1.5} />
            </WinButton>
            <WinButton label={win.maximized ? strings.restore : strings.maximize} onClick={onToggleMaximize}>
              {win.maximized ? (
                <Copy className="size-3.5" strokeWidth={1.5} />
              ) : (
                <Square className="size-3.5" strokeWidth={1.5} />
              )}
            </WinButton>
            <WinButton label={strings.close} onClick={onClose} danger>
              <X className="size-4" strokeWidth={1.5} />
            </WinButton>
          </>
        )}
      </div>
      <div className="relative min-h-0 flex-1">{children}</div>
    </section>
  )
}

function MacButton({
  label,
  color,
  onClick,
  children,
}: {
  label: string
  color: string
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={cn(
        'flex size-3 items-center justify-center rounded-full text-black/60 ring-1 ring-black/10',
        '[&>svg]:opacity-0 group-hover:[&>svg]:opacity-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-500',
        color,
      )}
    >
      {children}
    </button>
  )
}

function WinButton({
  label,
  onClick,
  danger,
  children,
}: {
  label: string
  onClick: () => void
  danger?: boolean
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={cn(
        'flex h-10 w-11 items-center justify-center text-zinc-700 transition-colors focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-sky-500',
        danger ? 'hover:bg-red-600 hover:text-white' : 'hover:bg-zinc-200',
      )}
    >
      {children}
    </button>
  )
}
