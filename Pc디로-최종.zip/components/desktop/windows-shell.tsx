'use client'

import { useEffect, useRef, useState } from 'react'
import { Power, RotateCcw, Search, Volume2, Wifi } from 'lucide-react'
import { APP_IDS, type AppId, type OsConfig } from '@/lib/os-config'
import { LOCALE_TAGS, type Translations } from '@/lib/i18n'
import { useClock } from '@/lib/use-clock'
import type { WindowManager } from '@/lib/use-window-manager'
import { cn } from '@/lib/utils'
import { AppIcon } from './app-icon'

interface WindowsShellProps {
  config: OsConfig
  strings: Translations
  wm: WindowManager
  onLaunch: (id: AppId) => void
  onShutDown: () => void
  onRestart: () => void
}

export function WindowsShell({ config, strings, wm, onLaunch, onShutDown, onRestart }: WindowsShellProps) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [query, setQuery] = useState('')
  const menuRef = useRef<HTMLDivElement>(null)
  const now = useClock()
  const isWin11 = config.version === 'win11'
  const locale = LOCALE_TAGS[config.language]

  useEffect(() => {
    if (!menuOpen) return
    function onDown(e: PointerEvent) {
      const target = e.target as HTMLElement
      if (menuRef.current?.contains(target) || target.closest('[data-start-button]')) return
      setMenuOpen(false)
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') setMenuOpen(false)
    }
    window.addEventListener('pointerdown', onDown)
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('pointerdown', onDown)
      window.removeEventListener('keydown', onKey)
    }
  }, [menuOpen])

  const filtered = APP_IDS.filter((id) => strings.apps[id].toLowerCase().includes(query.toLowerCase()))

  function launch(id: AppId) {
    onLaunch(id)
    setMenuOpen(false)
    setQuery('')
  }

  function onTaskbarClick(id: AppId) {
    const win = wm.windows.find((w) => w.id === id)
    if (!win) onLaunch(id)
    else if (wm.activeId === id && !win.minimized) wm.minimize(id)
    else wm.focus(id)
  }

  return (
    <>
      {menuOpen && (
        <div
          ref={menuRef}
          role="menu"
          aria-label={strings.start}
          className={cn(
            'absolute bottom-14 z-[9000] flex w-[min(36rem,calc(100%-1rem))] flex-col border border-white/10 bg-zinc-900/90 text-zinc-100 shadow-2xl backdrop-blur-2xl animate-in fade-in slide-in-from-bottom-4',
            isWin11 ? 'left-1/2 -translate-x-1/2 rounded-xl' : 'left-0 rounded-tr-lg sm:left-0',
          )}
        >
          <div className="p-5 pb-3">
            <label className="flex items-center gap-2 rounded-full border border-white/10 bg-zinc-800 px-4 py-2 focus-within:border-sky-400">
              <Search className="size-4 text-zinc-400" />
              <span className="sr-only">{strings.searchPlaceholder}</span>
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.nativeEvent.isComposing && e.keyCode !== 229 && filtered[0])
                    launch(filtered[0])
                }}
                placeholder={strings.searchPlaceholder}
                className="flex-1 bg-transparent text-sm outline-none placeholder:text-zinc-500"
              />
            </label>
          </div>
          <div className="px-6">
            <p className="text-xs font-semibold">{strings.pinned}</p>
            <div className="mt-3 grid grid-cols-3 gap-1 sm:grid-cols-6">
              {filtered.map((id) => (
                <button
                  key={id}
                  role="menuitem"
                  type="button"
                  onClick={() => launch(id)}
                  className="flex flex-col items-center gap-2 rounded-md px-1 py-3 text-center hover:bg-white/10"
                >
                  <AppIcon id={id} os="windows" size={32} />
                  <span className="line-clamp-2 text-[11px] leading-tight">{strings.apps[id]}</span>
                </button>
              ))}
            </div>
            <p className="mt-5 text-xs font-semibold">{strings.recommended}</p>
            <p className="mt-2 pb-5 text-xs text-zinc-400">{strings.recommendedEmpty}</p>
          </div>
          <div className="flex items-center justify-between rounded-b-xl border-t border-white/10 bg-black/20 px-6 py-3">
            <span className="flex items-center gap-2 text-xs">
              <span className="flex size-7 items-center justify-center rounded-full bg-sky-600 text-xs font-semibold">
                G
              </span>
              {strings.user}
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={onRestart}
                aria-label={strings.restart}
                title={strings.restart}
                className="rounded-md p-2 hover:bg-white/10"
              >
                <RotateCcw className="size-4" />
              </button>
              <button
                type="button"
                onClick={onShutDown}
                aria-label={strings.shutDown}
                title={strings.shutDown}
                className="rounded-md p-2 hover:bg-white/10"
              >
                <Power className="size-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      <footer
        className={cn(
          'absolute inset-x-0 bottom-0 z-[8000] flex h-12 items-center border-t border-white/10 bg-zinc-900/80 text-zinc-100 backdrop-blur-2xl',
        )}
      >
        <nav
          aria-label="Taskbar"
          className={cn('flex h-full min-w-0 flex-1 items-center gap-0.5 px-1', isWin11 && 'justify-center')}
        >
          <button
            type="button"
            data-start-button
            aria-label={strings.start}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((o) => !o)}
            className={cn(
              'flex size-10 shrink-0 items-center justify-center rounded-md hover:bg-white/10',
              menuOpen && 'bg-white/10',
            )}
          >
            <StartGlyph />
          </button>
          {!isWin11 && (
            <div className="mx-1 hidden h-9 w-52 items-center gap-2 bg-white/90 px-3 text-xs text-zinc-500 md:flex">
              <Search className="size-4" />
              {strings.searchPlaceholder}
            </div>
          )}
          {isWin11 && (
            <button
              type="button"
              aria-label={strings.searchPlaceholder}
              onClick={() => setMenuOpen(true)}
              className="hidden size-10 shrink-0 items-center justify-center rounded-md hover:bg-white/10 sm:flex"
            >
              <Search className="size-4" />
            </button>
          )}
          <div className="flex min-w-0 items-center gap-0.5 overflow-x-auto">
            {APP_IDS.map((id) => {
              const win = wm.windows.find((w) => w.id === id)
              const isActive = wm.activeId === id
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onTaskbarClick(id)}
                  aria-label={strings.apps[id]}
                  title={strings.apps[id]}
                  className={cn(
                    'relative flex size-10 shrink-0 items-center justify-center hover:bg-white/10',
                    isWin11 ? 'rounded-md' : 'rounded-none',
                    isActive && 'bg-white/10',
                  )}
                >
                  <AppIcon id={id} os="windows" size={24} />
                  {win && (
                    <span
                      className={cn(
                        'absolute bottom-0.5 h-[3px] rounded-full bg-sky-400 transition-all',
                        isActive ? 'w-4' : 'w-1.5 bg-zinc-400',
                        !isWin11 && 'bottom-0 w-full rounded-none',
                      )}
                    />
                  )}
                </button>
              )
            })}
          </div>
        </nav>
        <div className="flex h-full shrink-0 items-center gap-2 px-3 text-xs">
          <span className="hidden items-center gap-2 sm:flex">
            <Wifi className="size-4" />
            <Volume2 className="size-4" />
          </span>
          <span className="hidden text-[11px] uppercase text-zinc-300 sm:inline">{config.language}</span>
          {now && (
            <time dateTime={now.toISOString()} className="flex flex-col items-end leading-tight">
              <span>{now.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })}</span>
              <span className="text-[11px] text-zinc-300">{now.toLocaleDateString(locale)}</span>
            </time>
          )}
        </div>
      </footer>
    </>
  )
}

function StartGlyph() {
  return (
    <span aria-hidden="true" className="grid grid-cols-2 gap-[2px]">
      <span className="size-[9px] rounded-[1px] bg-sky-400" />
      <span className="size-[9px] rounded-[1px] bg-sky-400" />
      <span className="size-[9px] rounded-[1px] bg-sky-400" />
      <span className="size-[9px] rounded-[1px] bg-sky-300" />
    </span>
  )
}
