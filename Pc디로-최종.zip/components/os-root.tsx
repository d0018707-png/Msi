'use client'

import { OsStoreProvider, useOsStore } from '@/lib/os-store'
import { SetupScreen } from './setup/setup-screen'
import { BootScreen, LoadingScreen, VmScreen } from './screens/transition-screens'
import { Desktop } from './desktop/desktop'

function PhaseRouter() {
  const { phase, running } = useOsStore()
  if (phase === 'loading') return <LoadingScreen />
  if (phase === 'vm') return <VmScreen />
  if (phase === 'booting' && running) return <BootScreen key={JSON.stringify(running)} config={running} />
  if (phase === 'desktop' && running) return <Desktop key={JSON.stringify(running)} config={running} />
  return <SetupScreen />
}

export function OsRoot() {
  return (
    <OsStoreProvider>
      <PhaseRouter />
    </OsStoreProvider>
  )
}
