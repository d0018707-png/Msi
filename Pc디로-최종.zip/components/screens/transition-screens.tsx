'use client'

import { useEffect } from 'react'
import { ArrowLeft } from 'lucide-react'
import { versionLabel, type OsConfig } from '@/lib/os-config'
import { t } from '@/lib/i18n'
import { useOsStore } from '@/lib/os-store'
import { VmLauncher } from '@/components/vm/vm-launcher'

export function LoadingScreen() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-6 bg-zinc-950 text-zinc-100">
      <div aria-hidden="true" className="grid grid-cols-2 gap-1.5">
        {[0, 1, 2, 3].map((i) => (
          <span
            key={i}
            className="size-5 animate-pulse rounded-md bg-sky-400"
            style={{ animationDelay: `${i * 150}ms` }}
          />
        ))}
      </div>
      <p className="text-sm font-medium tracking-wide text-zinc-400" role="status">
        Web OS Emulator
      </p>
    </main>
  )
}

export function BootScreen({ config }: { config: OsConfig }) {
  const { setPhase } = useOsStore()
  const strings = t(config.language)
  const isMac = config.os === 'macos'

  useEffect(() => {
    const id = window.setTimeout(() => setPhase('desktop'), 2200)
    return () => window.clearTimeout(id)
  }, [setPhase])

  return (
    <main
      lang={config.language}
      className="flex min-h-dvh flex-col items-center justify-center gap-8 bg-black text-white animate-in fade-in duration-500"
      role="status"
      aria-label={strings.preparing}
    >
      {isMac ? (
        <>
          <span aria-hidden="true" className="relative block size-16">
            <span className="absolute inset-0 rounded-full border-4 border-white" />
            <span className="absolute left-1/2 top-1/2 size-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white" />
          </span>
          <div className="h-1 w-48 overflow-hidden rounded-full bg-white/20">
            <div className="h-full origin-left animate-[boot-progress_2.1s_ease-in-out_forwards] bg-white" />
          </div>
        </>
      ) : (
        <>
          <span aria-hidden="true" className="grid grid-cols-2 gap-1">
            {[0, 1, 2, 3].map((i) => (
              <span key={i} className="size-8 bg-sky-400" />
            ))}
          </span>
          <span
            aria-hidden="true"
            className="size-8 animate-spin rounded-full border-[3px] border-white/20 border-t-white"
          />
          <p className="text-sm text-zinc-300">{strings.welcome}</p>
        </>
      )}
      <p className="text-xs text-zinc-500">{versionLabel(config.os, config.version)}</p>
    </main>
  )
}

export function VmScreen() {
  const { setPhase, draft } = useOsStore()
  const language = draft.language ?? 'ko'
  return (
    <main lang={language} className="flex h-dvh flex-col bg-zinc-950 animate-in fade-in duration-300">
      <header className="flex items-center gap-2 border-b border-white/10 px-3 py-2">
        <button
          type="button"
          onClick={() => setPhase('select')}
          className="flex items-center gap-1.5 rounded-md px-2 py-1 text-sm text-zinc-300 hover:bg-white/10"
        >
          <ArrowLeft className="size-4" />
          {language === 'en' ? 'Back' : language === 'ja' ? '戻る' : '돌아가기'}
        </button>
      </header>
      <div className="min-h-0 flex-1">
        <VmLauncher language={language} dark />
      </div>
    </main>
  )
}
