'use client'

import { Check, Cpu, Monitor, Play } from 'lucide-react'
import { LANGUAGES, OS_VERSIONS, versionLabel, type Language, type OsFamily } from '@/lib/os-config'
import { useOsStore } from '@/lib/os-store'
import { cn } from '@/lib/utils'
import { SitePortal } from '@/components/site-portal'

const UI = {
  ko: {
    eyebrow: '웹 OS 에뮬레이터',
    title: '사용할 데스크톱 환경을 선택하세요',
    subtitle: '운영체제, 버전, 언어를 고른 뒤 시작을 누르면 브라우저 안에서 데스크톱이 실행됩니다.',
    step1: '운영체제',
    step2: '버전',
    step3: '언어',
    pickOsFirst: '먼저 운영체제를 선택하세요.',
    summary: '선택 요약',
    notSelected: '선택 안 함',
    start: '시작',
    startHint: '모든 항목을 선택하면 시작할 수 있습니다.',
    winDesc: '작업 표시줄과 시작 메뉴',
    macDesc: '상단 메뉴 바와 Dock',
    vmTitle: '가상머신 실행기',
    vmDesc: '실제 x86 OS 이미지를 v86 에뮬레이터로 부팅',
    open: '열기',
  },
  en: {
    eyebrow: 'Web OS Emulator',
    title: 'Choose your desktop environment',
    subtitle: 'Pick an operating system, version and language, then press Start to launch the desktop in your browser.',
    step1: 'Operating system',
    step2: 'Version',
    step3: 'Language',
    pickOsFirst: 'Select an operating system first.',
    summary: 'Summary',
    notSelected: 'Not selected',
    start: 'Start',
    startHint: 'Complete every selection to start.',
    winDesc: 'Taskbar and Start menu',
    macDesc: 'Menu bar and Dock',
    vmTitle: 'VM Launcher',
    vmDesc: 'Boot real x86 OS images with the v86 emulator',
    open: 'Open',
  },
  zh: {
    eyebrow: '网页操作系统模拟器',
    title: '选择要使用的桌面环境',
    subtitle: '选择操作系统、版本和语言，然后点击开始，即可在浏览器中打开桌面。',
    step1: '操作系统', step2: '版本', step3: '语言', pickOsFirst: '请先选择操作系统。',
    summary: '选择摘要', notSelected: '未选择', start: '开始', startHint: '完成所有选择后即可开始。',
    winDesc: '任务栏和开始菜单', macDesc: '顶部菜单栏和 Dock',
    vmTitle: '虚拟机启动器', vmDesc: '通过 v86 模拟器启动真实 x86 系统镜像', open: '打开',
  },
  ja: {
    eyebrow: 'Web OS エミュレータ',
    title: 'デスクトップ環境を選択してください',
    subtitle: 'OS、バージョン、言語を選んでスタートを押すと、ブラウザ内でデスクトップが起動します。',
    step1: 'オペレーティングシステム',
    step2: 'バージョン',
    step3: '言語',
    pickOsFirst: '先に OS を選択してください。',
    summary: '選択内容',
    notSelected: '未選択',
    start: 'スタート',
    startHint: 'すべて選択するとスタートできます。',
    winDesc: 'タスクバーとスタートメニュー',
    macDesc: 'メニューバーと Dock',
    vmTitle: '仮想マシンランチャー',
    vmDesc: 'v86 エミュレータで実際の x86 OS イメージを起動',
    open: '開く',
  },
} satisfies Record<Language, Record<string, string>>

export function SetupScreen() {
  const { draft, selectOs, selectVersion, selectLanguage, boot, setPhase } = useOsStore()
  const ui = UI[draft.language ?? 'ko']
  const ready = Boolean(draft.os && draft.version && draft.language)

  return (
    <main
      lang={draft.language ?? 'ko'}
      className="min-h-dvh bg-zinc-950 px-4 py-8 text-zinc-100 animate-in fade-in duration-500 sm:px-6 sm:py-12"
    >
      <div className="mx-auto flex max-w-5xl flex-col gap-8">
        <header className="flex flex-col gap-3">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-sky-400">{ui.eyebrow}</p>
          <h1 className="text-balance text-3xl font-semibold tracking-tight sm:text-4xl">{ui.title}</h1>
          <p className="max-w-2xl text-pretty text-sm leading-relaxed text-zinc-400">{ui.subtitle}</p>
        </header>

        <div className="grid gap-6 lg:grid-cols-[1fr_20rem]">
          <div className="flex flex-col gap-8">
            <Step index={1} title={ui.step1}>
              <div role="radiogroup" aria-label={ui.step1} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <OsCard
                  os="windows"
                  name="Windows"
                  desc={ui.winDesc}
                  selected={draft.os === 'windows'}
                  onSelect={() => selectOs('windows')}
                />
                <OsCard
                  os="macos"
                  name="macOS"
                  desc={ui.macDesc}
                  selected={draft.os === 'macos'}
                  onSelect={() => selectOs('macos')}
                />
              </div>
            </Step>

            <Step index={2} title={ui.step2}>
              {draft.os ? (
                <div role="radiogroup" aria-label={ui.step2} className="grid max-h-80 gap-2 overflow-y-auto pr-1 sm:grid-cols-2 xl:grid-cols-3">
                  {OS_VERSIONS[draft.os].map((v) => (
                    <OptionButton
                      key={v.id}
                      selected={draft.version === v.id}
                      onSelect={() => selectVersion(v.id)}
                      title={v.label}
                      meta={`${v.codename} · ${v.year}`}
                    />
                  ))}
                </div>
              ) : (
                <p className="rounded-lg border border-dashed border-white/10 px-4 py-5 text-sm text-zinc-500">
                  {ui.pickOsFirst}
                </p>
              )}
            </Step>

            <Step index={3} title={ui.step3}>
              <div role="radiogroup" aria-label={ui.step3} className="grid grid-cols-3 gap-2">
                {LANGUAGES.map((l) => (
                  <OptionButton
                    key={l.id}
                    selected={draft.language === l.id}
                    onSelect={() => selectLanguage(l.id)}
                    title={l.native}
                    meta={l.label}
                  />
                ))}
              </div>
            </Step>
          </div>

          <aside className="flex flex-col gap-4 lg:sticky lg:top-8 lg:self-start">
            <section
              aria-labelledby="summary-title"
              className="rounded-2xl border border-white/10 bg-zinc-900 p-5"
            >
              <h2 id="summary-title" className="text-sm font-semibold">
                {ui.summary}
              </h2>
              <dl className="mt-4 flex flex-col gap-3 text-sm">
                <SummaryRow
                  label={ui.step1}
                  value={draft.os ? (draft.os === 'windows' ? 'Windows' : 'macOS') : null}
                  empty={ui.notSelected}
                />
                <SummaryRow
                  label={ui.step2}
                  value={draft.os && draft.version ? versionLabel(draft.os, draft.version) : null}
                  empty={ui.notSelected}
                />
                <SummaryRow
                  label={ui.step3}
                  value={LANGUAGES.find((l) => l.id === draft.language)?.native ?? null}
                  empty={ui.notSelected}
                />
              </dl>
              <button
                type="button"
                disabled={!ready}
                onClick={() =>
                  draft.os &&
                  draft.version &&
                  draft.language &&
                  boot({ os: draft.os, version: draft.version, language: draft.language })
                }
                className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg bg-sky-500 px-4 py-2.5 text-sm font-semibold text-zinc-950 transition-colors hover:bg-sky-400 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-400 disabled:cursor-not-allowed disabled:bg-zinc-800 disabled:text-zinc-500"
              >
                <Play className="size-4" />
                {ui.start}
              </button>
              {!ready && <p className="mt-2 text-center text-xs text-zinc-500">{ui.startHint}</p>}
            </section>

            <button
              type="button"
              onClick={() => setPhase('vm')}
              className="group flex items-center gap-3 rounded-2xl border border-white/10 bg-zinc-900 p-4 text-left transition-colors hover:border-emerald-400/50"
            >
              <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400">
                <Cpu className="size-5" />
              </span>
              <span className="flex min-w-0 flex-1 flex-col">
                <span className="text-sm font-semibold">{ui.vmTitle}</span>
                <span className="text-xs text-zinc-400">{ui.vmDesc}</span>
              </span>
              <span className="text-xs font-medium text-emerald-400 group-hover:underline">{ui.open}</span>
            </button>
          </aside>
        </div>
      </div>
      <SitePortal language={draft.language ?? 'ko'} />
    </main>
  )
}

function Step({ index, title, children }: { index: number; title: string; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-3">
      <h2 className="flex items-center gap-2 text-sm font-medium text-zinc-300">
        <span className="flex size-5 items-center justify-center rounded-full bg-white/10 text-[11px]">{index}</span>
        {title}
      </h2>
      {children}
    </section>
  )
}

function OsCard({
  os,
  name,
  desc,
  selected,
  onSelect,
}: {
  os: OsFamily
  name: string
  desc: string
  selected: boolean
  onSelect: () => void
}) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      onClick={onSelect}
      className={cn(
        'group relative overflow-hidden rounded-2xl border bg-zinc-900 text-left transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-400',
        selected ? 'border-sky-400 ring-1 ring-sky-400' : 'border-white/10 hover:border-white/25',
      )}
    >
      <div
        className="relative aspect-[16/9] bg-cover bg-center"
        style={{ backgroundImage: `url(/wallpapers/${os}.png)` }}
      >
        {os === 'windows' ? <WindowsPreview /> : <MacPreview />}
      </div>
      <div className="flex items-center justify-between gap-3 p-4">
        <div>
          <p className="font-semibold">{name}</p>
          <p className="text-xs text-zinc-400">{desc}</p>
        </div>
        <span
          className={cn(
            'flex size-6 shrink-0 items-center justify-center rounded-full border',
            selected ? 'border-sky-400 bg-sky-400 text-zinc-950' : 'border-white/20',
          )}
        >
          {selected ? <Check className="size-3.5" strokeWidth={3} /> : <Monitor className="size-3 text-zinc-500" />}
        </span>
      </div>
    </button>
  )
}

function WindowsPreview() {
  return (
    <div aria-hidden="true" className="absolute inset-0">
      <div className="absolute left-[18%] top-[16%] h-[52%] w-[56%] rounded-md bg-white/90 shadow-lg">
        <div className="flex h-3 justify-end gap-1 px-1.5 pt-1">
          <span className="h-1 w-1.5 bg-zinc-400" />
          <span className="h-1 w-1.5 bg-zinc-400" />
          <span className="h-1 w-1.5 bg-red-400" />
        </div>
      </div>
      <div className="absolute inset-x-0 bottom-0 flex h-[13%] items-center justify-center gap-1 bg-zinc-900/80">
        {[0, 1, 2, 3, 4].map((i) => (
          <span key={i} className={cn('size-2.5 rounded-sm', i === 0 ? 'bg-sky-400' : 'bg-white/50')} />
        ))}
      </div>
    </div>
  )
}

function MacPreview() {
  return (
    <div aria-hidden="true" className="absolute inset-0">
      <div className="absolute inset-x-0 top-0 h-[7%] bg-black/25" />
      <div className="absolute left-[22%] top-[18%] h-[50%] w-[56%] rounded-lg bg-white/90 shadow-lg">
        <div className="flex gap-1 px-1.5 pt-1.5">
          <span className="size-1.5 rounded-full bg-[#ff5f57]" />
          <span className="size-1.5 rounded-full bg-[#febc2e]" />
          <span className="size-1.5 rounded-full bg-[#28c840]" />
        </div>
      </div>
      <div className="absolute bottom-[5%] left-1/2 flex -translate-x-1/2 gap-1 rounded-md bg-white/30 p-1">
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <span key={i} className="size-2.5 rounded-[3px] bg-white/70" />
        ))}
      </div>
    </div>
  )
}

function OptionButton({
  selected,
  onSelect,
  title,
  meta,
}: {
  selected: boolean
  onSelect: () => void
  title: string
  meta: string
}) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      onClick={onSelect}
      className={cn(
        'flex items-center justify-between gap-2 rounded-xl border px-4 py-3 text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-400',
        selected ? 'border-sky-400 bg-sky-400/10' : 'border-white/10 bg-zinc-900 hover:border-white/25',
      )}
    >
      <span className="flex min-w-0 flex-col">
        <span className="truncate text-sm font-medium">{title}</span>
        <span className="truncate text-xs text-zinc-500">{meta}</span>
      </span>
      {selected && <Check className="size-4 shrink-0 text-sky-400" />}
    </button>
  )
}

function SummaryRow({ label, value, empty }: { label: string; value: string | null; empty: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-zinc-400">{label}</dt>
      <dd className={cn('truncate text-right font-medium', !value && 'text-zinc-600')}>{value ?? empty}</dd>
    </div>
  )
}
