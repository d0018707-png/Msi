'use client'

import { useState } from 'react'
import type { Language } from '@/lib/os-config'

type Panel = 'about' | 'terms' | 'rules' | 'contact' | 'report' | 'feedback' | 'login' | 'signup' | 'history'
const COPY = {
  ko: { button:'도움말 · 계정', title:'사이트 안내 센터', about:'사이트 소개', terms:'이용약관', rules:'불법 이용 금지·제재 규정', contact:'문의센터', report:'오류 신고', feedback:'피드백', login:'로그인', signup:'회원가입', history:'사용 기록', close:'닫기', send:'이 기기에 임시 저장', name:'이름 또는 닉네임', email:'이메일(선택)', message:'내용을 입력하세요', username:'아이디', password:'비밀번호', demo:'데모 화면입니다. 서버 인증/메일 발송은 아직 연결되지 않았으며, 계정 및 문의 내용은 실제로 서버에 제출되지 않습니다.', saved:'이 기기의 브라우저에 임시 저장했습니다.', aboutText:'이 사이트는 브라우저에서 Windows/macOS 스타일 데스크톱과 앱 인터페이스를 체험하는 시뮬레이션 프로젝트입니다. 실제 운영체제나 공식 Chrome, Discord, Roblox 프로그램을 그대로 제공하는 제품은 아닙니다.', termsText:'사이트는 개인적인 체험 및 학습 목적으로 제공됩니다. 사용자는 관련 법률과 타인의 권리를 준수해야 합니다. 서비스는 예고 없이 변경되거나 중단될 수 있으며, 데이터 손실에 대비해 중요한 자료를 별도로 보관해야 합니다. 계정 기능은 서버 연결 전까지 데모입니다.', rulesText:'불법 행위, 사기, 피싱, 악성코드 배포, 저작권 침해, 무단 접근, 서비스 방해, 타인 괴롭힘 및 개인정보 침해를 금지합니다. 위반이 확인되면 기능 제한, 자료 삭제, 계정 정지 또는 영구 이용 제한이 적용될 수 있으며, 필요한 경우 관계 기관에 신고할 수 있습니다. 실제 제재는 증거와 관련 법률 및 정식 운영정책에 따라 결정됩니다.', contactText:'문의 양식은 현재 데모입니다. 서버/운영 이메일이 연결되지 않았으므로 아래 내용을 임시 저장해도 운영자에게 자동 전달되지 않습니다.', reportText:'화면 오류, 앱 실행 실패, 표시 문제 등 재현 가능한 정보를 적어 주세요.', feedbackText:'개선 제안이나 원하는 기능을 알려 주세요.' },
  en: { button:'Help · Account', title:'Site help center', about:'About', terms:'Terms of use', rules:'Prohibited use & enforcement', contact:'Contact center', report:'Report a bug', feedback:'Feedback', login:'Log in', signup:'Sign up', history:'Activity history', close:'Close', send:'Save temporarily on this device', name:'Name or nickname', email:'Email (optional)', message:'Describe your message', username:'Username', password:'Password', demo:'Prototype only. Server authentication and email delivery are not connected. Account and support submissions are not sent to a server.', saved:'Saved temporarily in this browser on this device.', aboutText:'This project simulates Windows/macOS-style desktop interfaces and apps in a browser. It does not provide full operating systems or official Chrome, Discord, or Roblox desktop applications.', termsText:'Use this site for personal exploration and learning. Follow applicable laws and respect others’ rights. Features may change or be interrupted without notice. Keep separate backups of important data. Accounts are demo-only until server authentication is connected.', rulesText:'Illegal activity, fraud, phishing, malware distribution, copyright infringement, unauthorized access, service disruption, harassment, and privacy violations are prohibited. Violations may lead to feature restrictions, content removal, account suspension, or permanent bans. Where appropriate, incidents may be reported to relevant authorities. Actual enforcement requires evidence and applicable policies and law.', contactText:'This contact form is a prototype. No operator email or server is connected, so saved messages are not automatically delivered to staff.', reportText:'Describe reproducible UI errors, app launch failures, or display problems.', feedbackText:'Share suggestions or features you would like to see.' },
  zh: { button:'帮助 · 账户', title:'网站帮助中心', about:'网站介绍', terms:'使用条款', rules:'禁止非法使用与处罚规则', contact:'联系中心', report:'错误报告', feedback:'反馈建议', login:'登录', signup:'注册', history:'使用记录', close:'关闭', send:'暂存到此设备', name:'姓名或昵称', email:'电子邮件（选填）', message:'请描述内容', username:'用户名', password:'密码', demo:'这是原型界面。服务器身份验证和邮件发送尚未连接，账户和咨询内容不会提交到服务器。', saved:'已暂存在此设备的浏览器中。', aboutText:'本项目用于在浏览器中体验 Windows/macOS 风格的桌面和应用界面，并非完整操作系统，也不提供官方 Chrome、Discord 或 Roblox 桌面程序。', termsText:'请将本站用于个人体验和学习，并遵守适用法律及他人权利。服务可能变更或中断。重要数据请另行备份。服务器认证接入前，账户功能仅为演示。', rulesText:'禁止违法活动、诈骗、钓鱼、传播恶意软件、侵犯版权、未经授权访问、干扰服务、骚扰他人及侵犯隐私。违规可能导致功能限制、内容删除、账户暂停或永久封禁；必要时可向有关机构报告。实际处罚应依据证据、适用法律和正式政策执行。', contactText:'此联系表单仅为原型。尚未连接运营邮箱或服务器，因此暂存内容不会自动发送给工作人员。', reportText:'请描述可复现的界面错误、应用启动失败或显示问题。', feedbackText:'请分享改进建议或希望添加的功能。' },
  ja: { button:'ヘルプ・アカウント', title:'サイトサポートセンター', about:'サイト紹介', terms:'利用規約', rules:'違法利用禁止・措置規定', contact:'お問い合わせ', report:'不具合報告', feedback:'フィードバック', login:'ログイン', signup:'新規登録', history:'利用履歴', close:'閉じる', send:'この端末に一時保存', name:'名前またはニックネーム', email:'メール（任意）', message:'内容を入力してください', username:'ユーザー名', password:'パスワード', demo:'試作画面です。サーバー認証・メール送信は未接続のため、アカウント情報や問い合わせはサーバーへ送信されません。', saved:'この端末のブラウザーに一時保存しました。', aboutText:'このプロジェクトは、ブラウザーで Windows/macOS 風のデスクトップとアプリ画面を体験するシミュレーションです。完全な OS や公式 Chrome、Discord、Roblox のデスクトップアプリを提供するものではありません。', termsText:'個人的な体験・学習目的で利用し、適用法令と他者の権利を尊重してください。サービスは予告なく変更・中断される場合があります。重要なデータは別途バックアップしてください。サーバー認証接続まではアカウント機能はデモです。', rulesText:'違法行為、詐欺、フィッシング、マルウェア配布、著作権侵害、不正アクセス、サービス妨害、嫌がらせ、プライバシー侵害は禁止です。違反時は機能制限、コンテンツ削除、アカウント停止または永久利用停止の対象となる場合があり、必要に応じて関係機関に通報します。実際の措置は証拠、適用法令、正式なポリシーに基づいて判断されます。', contactText:'お問い合わせフォームは試作です。運営メールやサーバーは未接続のため、保存内容は担当者に自動送信されません。', reportText:'再現可能な画面エラー、アプリ起動失敗、表示問題を記載してください。', feedbackText:'改善案や追加してほしい機能をお知らせください。' }
} as const

export function SitePortal({ language }: { language: Language }) {
  const c = COPY[language]
  const [panel, setPanel] = useState<Panel | null>(null)
  const [notice, setNotice] = useState('')
  const [form, setForm] = useState({ name:'', email:'', message:'', username:'', password:'' })
  const links: { key: Panel; label: string }[] = [
    {key:'about',label:c.about},{key:'terms',label:c.terms},{key:'rules',label:c.rules},
    {key:'contact',label:c.contact},{key:'report',label:c.report},{key:'feedback',label:c.feedback},{key:'history',label:c.history},
    {key:'login',label:c.login},{key:'signup',label:c.signup},
  ]
  const title = panel ? links.find(x => x.key === panel)?.label ?? c.title : c.title
  function save() {
    try {
      const key = 'desktop-os-support-drafts'
      const raw = localStorage.getItem(key)
      const parsed: unknown = raw ? JSON.parse(raw) : []
      const previous = Array.isArray(parsed) ? parsed : []
      const { password: _password, ...safeForm } = form
      previous.push({ panel, ...safeForm, createdAt: new Date().toISOString() })
      localStorage.setItem(key, JSON.stringify(previous.slice(-30)))
      setNotice(c.saved)
    } catch { setNotice(c.demo) }
  }
  return <div className="fixed right-3 top-3 z-[10000]">
    <button type="button" onClick={() => { setPanel(panel ? null : 'about'); setNotice('') }}
      className="rounded-full border border-white/15 bg-zinc-950/90 px-3 py-2 text-xs font-medium text-white shadow-lg backdrop-blur hover:bg-zinc-800">
      {c.button}
    </button>
    {panel && <div className="fixed inset-0 z-[10001] flex items-center justify-center bg-black/70 p-3 sm:p-6" role="dialog" aria-modal="true" aria-label={c.title}>
      <div className="max-h-[90dvh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-white/10 bg-zinc-950 p-4 text-zinc-100 shadow-2xl sm:p-6">
        <div className="flex items-start justify-between gap-3">
          <div><p className="text-xs uppercase tracking-widest text-sky-400">WEB DESKTOP</p><h2 className="mt-1 text-xl font-semibold">{title}</h2></div>
          <button type="button" onClick={() => setPanel(null)} className="rounded-lg px-3 py-1.5 text-sm hover:bg-white/10">{c.close}</button>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {links.map(item => <button key={item.key} type="button" onClick={() => {setPanel(item.key);setNotice('')}}
            className={`rounded-lg border px-2 py-2 text-xs ${panel===item.key?'border-sky-400 bg-sky-400/10':'border-white/10 bg-white/5 hover:bg-white/10'}`}>{item.label}</button>)}
        </div>
        {['about','terms','rules'].includes(panel) && <p className="mt-5 whitespace-pre-line text-sm leading-7 text-zinc-300">{panel==='about'?c.aboutText:panel==='terms'?c.termsText:c.rulesText}</p>}
        {panel === 'history' && <ActivityHistory language={language} />}
        {['contact','report','feedback','login','signup'].includes(panel) && <form className="mt-5 flex flex-col gap-3" onSubmit={e=>{e.preventDefault();save()}}>
          <p className="text-xs leading-5 text-amber-300">{c.demo}</p>
          {(panel==='login'||panel==='signup') ? <>
            <input required autoComplete="username" value={form.username} onChange={e=>setForm({...form,username:e.target.value})} placeholder={c.username} className="rounded-lg border border-white/10 bg-zinc-900 px-3 py-2 text-sm outline-none focus:border-sky-400"/>
            <input required type="password" autoComplete={panel==='login'?'current-password':'new-password'} value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder={c.password} className="rounded-lg border border-white/10 bg-zinc-900 px-3 py-2 text-sm outline-none focus:border-sky-400"/>
          </> : <>
            <input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder={c.name} className="rounded-lg border border-white/10 bg-zinc-900 px-3 py-2 text-sm outline-none focus:border-sky-400"/>
            <input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder={c.email} className="rounded-lg border border-white/10 bg-zinc-900 px-3 py-2 text-sm outline-none focus:border-sky-400"/>
            <textarea required value={form.message} onChange={e=>setForm({...form,message:e.target.value})} placeholder={panel==='report'?c.reportText:panel==='feedback'?c.feedbackText:c.message} rows={4} className="resize-y rounded-lg border border-white/10 bg-zinc-900 px-3 py-2 text-sm outline-none focus:border-sky-400"/>
          </>}
          <button type="submit" className="rounded-lg bg-sky-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-sky-400">{c.send}</button>
          {notice && <p role="status" className="text-sm text-emerald-300">{notice}</p>}
        </form>}
        <p className="mt-5 border-t border-white/10 pt-3 text-[11px] leading-5 text-zinc-500">{c.demo}</p>
      </div>
    </div>}
  </div>
}


function ActivityHistory({ language }: { language: Language }) {
  const [items, setItems] = useState<Array<{action:string;detail:string;os:string;version:string;language:string;at:string}>>([])
  const [ready, setReady] = useState(false)
  const labels = {ko:{empty:'아직 기록이 없습니다. 앱을 실행하면 이 기기에 기록됩니다.',clear:'기록 지우기',opened:'앱 실행',clearConfirm:'이 브라우저에 저장된 사용 기록을 지울까요?'},en:{empty:'No activity yet. Open apps to record usage on this device.',clear:'Clear history',opened:'App opened',clearConfirm:'Clear activity history saved in this browser?'},zh:{empty:'暂无记录。打开应用后会在此设备保存使用记录。',clear:'清除记录',opened:'已打开应用',clearConfirm:'清除此浏览器中保存的使用记录？'},ja:{empty:'履歴はありません。アプリを開くとこの端末に記録されます。',clear:'履歴を消去',opened:'アプリを起動',clearConfirm:'このブラウザーに保存された履歴を消去しますか？'}}[language]
  useEffect(() => {
    try {
      const raw = localStorage.getItem('webos-activity-log')
      const parsed: unknown = raw ? JSON.parse(raw) : []
      const valid = Array.isArray(parsed) ? parsed.filter((item): item is {action:string;detail:string;os:string;version:string;language:string;at:string} => Boolean(item) && typeof item === 'object' && typeof item.detail === 'string' && typeof item.at === 'string') : []
      setItems(valid.slice().reverse())
    } catch { setItems([]) }
    setReady(true)
  }, [])
  function clear() {
    if (!window.confirm(labels.clearConfirm)) return
    try {
      localStorage.removeItem('webos-activity-log')
      setItems([])
    } catch { /* Storage may be unavailable in private or restricted browsing. */ }
  }
  if (!ready) return <p className="mt-5 text-sm text-zinc-400">…</p>
  return <div className="mt-5">
    <div className="flex items-center justify-between gap-2"><p className="text-sm text-zinc-400">{items.length} {language==='ko'?'개 기록':language==='ja'?'件':language==='zh'?'条记录':'records'}</p><button type="button" onClick={clear} className="rounded-lg border border-white/10 px-3 py-1.5 text-xs hover:bg-white/10">{labels.clear}</button></div>
    {items.length===0 ? <p className="py-8 text-center text-sm text-zinc-400">{labels.empty}</p> : <ul className="mt-3 max-h-72 space-y-2 overflow-y-auto">{items.map((item,i)=><li key={item.at+i} className="rounded-lg border border-white/10 bg-white/5 p-3"><p className="text-sm font-medium">{labels.opened}: {item.detail}</p><p className="mt-1 text-xs text-zinc-400">{item.os} · {item.version} · {new Date(item.at).toLocaleString(language==='ko'?'ko-KR':language==='zh'?'zh-CN':language==='ja'?'ja-JP':'en-US')}</p></li>)}</ul>}
    <p className="mt-3 text-xs leading-5 text-amber-300">{language==='ko'?'기록은 이 브라우저에만 저장됩니다. 다른 기기와 동기화되거나 서버에 전송되지 않습니다.':language==='zh'?'记录仅保存在此浏览器中，不会同步到其他设备或发送到服务器。':language==='ja'?'履歴はこのブラウザー内にのみ保存され、他の端末とは同期されず、サーバーにも送信されません。':'History is stored only in this browser. It is not synced to other devices or sent to a server.'}</p>
  </div>
}
