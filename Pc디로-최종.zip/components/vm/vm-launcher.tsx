'use client'

import { useEffect, useRef, useState } from 'react'
import { Cpu, HardDrive, Keyboard, Maximize, Play, Power, RotateCcw, Upload } from 'lucide-react'
import type { Language } from '@/lib/os-config'
import { cn } from '@/lib/utils'

type DriveKind = 'fda' | 'cdrom' | 'hda'

interface V86Image {
  url?: string
  buffer?: ArrayBuffer | File
  async?: boolean
  size?: number
}

interface V86Instance {
  add_listener: (event: string, cb: (arg: unknown) => void) => void
  destroy: () => Promise<void>
  restart: () => void
  keyboard_set_enabled: (enabled: boolean) => void
  mouse_set_enabled: (enabled: boolean) => void
  screen_go_fullscreen: () => void
  keyboard_send_scancodes: (codes: number[]) => void
}

type V86Constructor = new (options: Record<string, unknown>) => V86Instance

declare global {
  interface Window {
    V86?: V86Constructor
  }
}

interface Preset {
  id: string
  name: string
  desc: Record<Language, string>
  url: string
  drive: DriveKind
  memoryMb: number
  sizeLabel: string
}

const PRESETS: Preset[] = [
  {
    id: 'kolibri',
    name: 'KolibriOS',
    desc: {
      ko: '그래픽 데스크톱을 갖춘 초경량 오픈소스 OS',
      en: 'Tiny open-source OS with a graphical desktop',
      ja: 'グラフィカルなデスクトップを備えた超軽量 OSS OS',
    },
    url: '/api/vm-image/kolibri',
    drive: 'fda',
    memoryMb: 128,
    sizeLabel: '1.4 MB',
  },
  {
    id: 'freedos',
    name: 'FreeDOS',
    desc: {
      ko: 'DOS 호환 오픈소스 운영체제',
      en: 'Open-source DOS-compatible operating system',
      ja: 'DOS 互換のオープンソース OS',
    },
    url: '/api/vm-image/freedos',
    drive: 'fda',
    memoryMb: 32,
    sizeLabel: '720 KB',
  },
  {
    id: 'linux',
    name: 'Linux (Buildroot)',
    desc: {
      ko: '콘솔 기반 경량 리눅스',
      en: 'Lightweight console Linux',
      ja: 'コンソールベースの軽量 Linux',
    },
    url: '/api/vm-image/linux',
    drive: 'cdrom',
    memoryMb: 64,
    sizeLabel: '7.4 MB',
  },
]

const STRINGS = {
  ko: {
    title: '가상머신 실행기',
    subtitle: 'WebAssembly 기반 x86 에뮬레이터(v86)로 실제 OS 디스크 이미지를 브라우저에서 부팅합니다.',
    presets: '샘플 이미지',
    custom: '내 디스크 이미지 불러오기',
    customDesc: '.iso / .img 파일 (사용 권한이 있는 이미지만)',
    memory: '메모리',
    boot: '부팅',
    loading: '이미지 다운로드 중',
    starting: '가상머신 시작 중...',
    running: '실행 중',
    stop: '전원 끄기',
    reset: '재시작',
    fullscreen: '전체 화면',
    ctrlAltDel: 'Ctrl+Alt+Del',
    keyboardHint: '화면을 클릭하면 키보드 입력이 가상머신으로 전달됩니다.',
    notice:
      'Windows 10/11과 macOS는 하드웨어 가상화가 필요하고 라이선스 제약이 있어 브라우저에서 실행할 수 없습니다. 경량 x86 OS 또는 직접 보유한 구형 OS 이미지를 사용하세요.',
    error: '가상머신을 시작하지 못했습니다.',
  },
  en: {
    title: 'VM Launcher',
    subtitle: 'Boot real OS disk images in your browser with v86, a WebAssembly x86 emulator.',
    presets: 'Sample images',
    custom: 'Load your own disk image',
    customDesc: '.iso / .img files (only images you are licensed to use)',
    memory: 'Memory',
    boot: 'Boot',
    loading: 'Downloading image',
    starting: 'Starting virtual machine...',
    running: 'Running',
    stop: 'Power off',
    reset: 'Reset',
    fullscreen: 'Fullscreen',
    ctrlAltDel: 'Ctrl+Alt+Del',
    keyboardHint: 'Click the screen to send keyboard input to the VM.',
    notice:
      'Windows 10/11 and macOS require hardware virtualization and have licensing restrictions, so they cannot run in a browser. Use lightweight x86 OSes or legacy images you own.',
    error: 'Failed to start the virtual machine.',
  },
  ja: {
    title: '仮想マシンランチャー',
    subtitle: 'WebAssembly 製 x86 エミュレータ (v86) で実際の OS イメージをブラウザ上で起動します。',
    presets: 'サンプルイメージ',
    custom: '自分のディスクイメージを読み込む',
    customDesc: '.iso / .img ファイル (使用権のあるイメージのみ)',
    memory: 'メモリ',
    boot: '起動',
    loading: 'イメージをダウンロード中',
    starting: '仮想マシンを起動しています...',
    running: '実行中',
    stop: '電源オフ',
    reset: 'リセット',
    fullscreen: '全画面',
    ctrlAltDel: 'Ctrl+Alt+Del',
    keyboardHint: '画面をクリックするとキーボード入力が仮想マシンに送られます。',
    notice:
      'Windows 10/11 と macOS はハードウェア仮想化が必要でライセンス制約もあるため、ブラウザでは実行できません。軽量な x86 OS か、所有する旧 OS イメージを使用してください。',
    error: '仮想マシンを起動できませんでした。',
  },
}

let scriptPromise: Promise<V86Constructor> | null = null

function loadV86(): Promise<V86Constructor> {
  if (window.V86) return Promise.resolve(window.V86)
  if (!scriptPromise) {
    scriptPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script')
      script.src = '/v86/libv86.js'
      script.async = true
      script.onload = () => (window.V86 ? resolve(window.V86) : reject(new Error('V86 not found')))
      script.onerror = () => {
        scriptPromise = null
        reject(new Error('Failed to load emulator'))
      }
      document.head.appendChild(script)
    })
  }
  return scriptPromise
}

type Status = 'idle' | 'loading' | 'running' | 'error'

interface VmLauncherProps {
  language: Language
  active?: boolean
  dark?: boolean
}

export function VmLauncher({ language, active = true, dark = false }: VmLauncherProps) {
  const s = STRINGS[language]
  const containerRef = useRef<HTMLDivElement>(null)
  const emulatorRef = useRef<V86Instance | null>(null)
  const [status, setStatus] = useState<Status>('idle')
  const [progress, setProgress] = useState<number | null>(null)
  const [memoryMb, setMemoryMb] = useState(128)
  const [running, setRunning] = useState<string | null>(null)
  const [errorMsg, setErrorMsg] = useState('')
  const [captured, setCaptured] = useState(false)

  useEffect(() => {
    emulatorRef.current?.keyboard_set_enabled(active && captured)
    emulatorRef.current?.mouse_set_enabled(active && captured)
  }, [active, captured])

  useEffect(() => {
    return () => {
      emulatorRef.current?.destroy()
      emulatorRef.current = null
    }
  }, [])

  useEffect(() => {
    if (!captured) return
    function release(e: PointerEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) setCaptured(false)
    }
    window.addEventListener('pointerdown', release)
    return () => window.removeEventListener('pointerdown', release)
  }, [captured])

  async function start(name: string, drive: DriveKind, image: V86Image, mem: number) {
    setStatus('loading')
    setProgress(null)
    setErrorMsg('')
    setRunning(name)
    try {
      await emulatorRef.current?.destroy()
      emulatorRef.current = null
      const V86 = await loadV86()
      const container = containerRef.current
      if (!container) return
      const emulator = new V86({
        wasm_path: '/v86/v86.wasm',
        memory_size: mem * 1024 * 1024,
        vga_memory_size: 8 * 1024 * 1024,
        screen_container: container,
        bios: { url: '/v86/seabios.bin' },
        vga_bios: { url: '/v86/vgabios.bin' },
        [drive]: image,
        boot_order: drive === 'cdrom' ? 0x123 : drive === 'fda' ? 0x321 : 0x213,
        autostart: true,
      })
      emulatorRef.current = emulator
      emulator.add_listener('download-progress', (e) => {
        const ev = e as { loaded: number; total: number; lengthComputable: boolean }
        if (ev.lengthComputable && ev.total) setProgress(Math.round((ev.loaded / ev.total) * 100))
      })
      emulator.add_listener('emulator-started', () => {
        setStatus('running')
        setCaptured(true)
      })
      emulator.add_listener('download-error', () => {
        setStatus('error')
        setErrorMsg(s.error)
      })
    } catch (err) {
      setStatus('error')
      setErrorMsg(err instanceof Error ? err.message : s.error)
    }
  }

  function startPreset(p: Preset) {
    start(p.name, p.drive, { url: p.url, async: false }, Math.max(memoryMb, p.memoryMb))
  }

  async function startFile(file: File) {
    const lower = file.name.toLowerCase()
    const drive: DriveKind = lower.endsWith('.iso') ? 'cdrom' : file.size <= 2_949_120 ? 'fda' : 'hda'
    const image: V86Image =
      file.size > 256 * 1024 * 1024 ? { buffer: file, async: true } : { buffer: await file.arrayBuffer() }
    start(file.name, drive, image, memoryMb)
  }

  async function powerOff() {
    await emulatorRef.current?.destroy()
    emulatorRef.current = null
    const container = containerRef.current
    if (container) {
      const text = container.querySelector('div')
      const canvas = container.querySelector('canvas')
      if (text) text.textContent = ''
      if (canvas) canvas.style.display = 'none'
    }
    setStatus('idle')
    setRunning(null)
    setCaptured(false)
  }

  const showScreen = status === 'loading' || status === 'running'

  return (
    <div className={cn('flex h-full flex-col', dark ? 'bg-zinc-950 text-zinc-100' : 'bg-zinc-50 text-zinc-900')}>
      {showScreen && (
        <div
          className={cn(
            'flex flex-wrap items-center gap-2 border-b px-3 py-1.5 text-xs',
            dark ? 'border-white/10 bg-zinc-900' : 'border-zinc-200 bg-white',
          )}
        >
          <span className="flex min-w-0 items-center gap-1.5 font-medium">
            <span
              className={cn('size-2 rounded-full', status === 'running' ? 'bg-emerald-500' : 'animate-pulse bg-amber-400')}
            />
            <span className="truncate">
              {running} · {status === 'running' ? s.running : s.starting}
            </span>
          </span>
          <div className="ml-auto flex items-center gap-1">
            <ToolbarButton
              dark={dark}
              label={s.ctrlAltDel}
              onClick={() => emulatorRef.current?.keyboard_send_scancodes([0x1d, 0x38, 0x53, 0xd3, 0xb8, 0x9d])}
            >
              <Keyboard className="size-3.5" />
            </ToolbarButton>
            <ToolbarButton dark={dark} label={s.reset} onClick={() => emulatorRef.current?.restart()}>
              <RotateCcw className="size-3.5" />
            </ToolbarButton>
            <ToolbarButton dark={dark} label={s.fullscreen} onClick={() => emulatorRef.current?.screen_go_fullscreen()}>
              <Maximize className="size-3.5" />
            </ToolbarButton>
            <ToolbarButton dark={dark} label={s.stop} onClick={powerOff} danger>
              <Power className="size-3.5" />
            </ToolbarButton>
          </div>
        </div>
      )}

      <div className={cn('relative min-h-0 flex-1 overflow-auto bg-black', !showScreen && 'hidden')}>
        <div
          ref={containerRef}
          tabIndex={0}
          onPointerDown={() => setCaptured(true)}
          aria-label="VM screen"
          className="vm-screen mx-auto flex min-h-full w-fit items-center justify-center outline-none"
        >
          <div className="whitespace-pre font-mono text-[14px] leading-[14px] text-white" />
          <canvas className="hidden" />
        </div>
        {status === 'loading' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black text-zinc-300">
            <Cpu className="size-8 animate-pulse text-emerald-400" />
            <p className="text-sm">{progress === null ? s.starting : `${s.loading} ${progress}%`}</p>
            <div className="h-1 w-48 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full bg-emerald-400 transition-[width]"
                style={{ width: `${progress ?? 15}%` }}
              />
            </div>
          </div>
        )}
        {status === 'running' && !captured && (
          <p className="pointer-events-none absolute inset-x-0 bottom-2 text-center text-[11px] text-white/60">
            {s.keyboardHint}
          </p>
        )}
      </div>

      {!showScreen && (
        <div className="min-h-0 flex-1 overflow-y-auto p-5">
          <div className="flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-500">
              <Cpu className="size-5" />
            </span>
            <div>
              <h3 className="text-lg font-semibold">{s.title}</h3>
              <p className={cn('text-xs text-pretty', dark ? 'text-zinc-400' : 'text-zinc-500')}>{s.subtitle}</p>
            </div>
          </div>

          {status === 'error' && (
            <p role="alert" className="mt-4 rounded-md bg-red-500/10 px-3 py-2 text-xs text-red-500">
              {errorMsg}
            </p>
          )}

          <h4 className={cn('mt-5 text-xs font-medium', dark ? 'text-zinc-400' : 'text-zinc-500')}>{s.presets}</h4>
          <ul className="mt-2 grid gap-2 sm:grid-cols-3">
            {PRESETS.map((p) => (
              <li key={p.id}>
                <button
                  type="button"
                  onClick={() => startPreset(p)}
                  className={cn(
                    'group flex h-full w-full flex-col items-start gap-1 rounded-lg border p-3 text-left transition-colors',
                    dark
                      ? 'border-white/10 bg-white/5 hover:border-emerald-400/60'
                      : 'border-zinc-200 bg-white hover:border-emerald-500',
                  )}
                >
                  <span className="flex w-full items-center justify-between text-sm font-medium">
                    {p.name}
                    <Play className="size-3.5 text-emerald-500 opacity-60 group-hover:opacity-100" />
                  </span>
                  <span className={cn('text-xs', dark ? 'text-zinc-400' : 'text-zinc-500')}>{p.desc[language]}</span>
                  <span className={cn('mt-auto pt-1 text-[11px]', dark ? 'text-zinc-500' : 'text-zinc-400')}>
                    {p.drive.toUpperCase()} · {p.sizeLabel}
                  </span>
                </button>
              </li>
            ))}
          </ul>

          <label
            className={cn(
              'mt-3 flex cursor-pointer items-center gap-3 rounded-lg border border-dashed p-3 transition-colors focus-within:ring-2 focus-within:ring-emerald-500',
              dark ? 'border-white/20 hover:bg-white/5' : 'border-zinc-300 hover:bg-white',
            )}
          >
            <Upload className="size-4 text-emerald-500" />
            <span className="flex flex-col">
              <span className="text-sm font-medium">{s.custom}</span>
              <span className={cn('text-xs', dark ? 'text-zinc-400' : 'text-zinc-500')}>{s.customDesc}</span>
            </span>
            <input
              type="file"
              accept=".iso,.img,.ima,.vfd,.bin"
              className="sr-only"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) startFile(file)
                e.target.value = ''
              }}
            />
          </label>

          <div className="mt-4 flex items-center gap-3">
            <label htmlFor="vm-memory" className="flex items-center gap-2 text-xs font-medium">
              <HardDrive className="size-3.5" />
              {s.memory}
            </label>
            <select
              id="vm-memory"
              value={memoryMb}
              onChange={(e) => setMemoryMb(Number(e.target.value))}
              className={cn(
                'rounded-md border px-2 py-1 text-xs',
                dark ? 'border-white/10 bg-zinc-900' : 'border-zinc-300 bg-white',
              )}
            >
              {[32, 64, 128, 256, 512].map((m) => (
                <option key={m} value={m}>
                  {m} MB
                </option>
              ))}
            </select>
          </div>

          <p
            className={cn(
              'mt-5 rounded-lg p-3 text-[11px] leading-relaxed text-pretty',
              dark ? 'bg-white/5 text-zinc-400' : 'bg-zinc-100 text-zinc-500',
            )}
          >
            {s.notice}
          </p>
        </div>
      )}
    </div>
  )
}

function ToolbarButton({
  label,
  onClick,
  danger,
  dark,
  children,
}: {
  label: string
  onClick: () => void
  danger?: boolean
  dark?: boolean
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      aria-label={label}
      className={cn(
        'flex items-center gap-1 rounded px-2 py-1 transition-colors',
        dark ? 'hover:bg-white/10' : 'hover:bg-zinc-100',
        danger && 'text-red-500',
      )}
    >
      {children}
      <span className="hidden md:inline">{label}</span>
    </button>
  )
}
