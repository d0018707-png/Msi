export type OsFamily = 'windows' | 'macos'
export type Language = 'ko' | 'en' | 'zh' | 'ja'
export type AppId = 'files' | 'notepad' | 'calculator' | 'settings' | 'browser' | 'chrome' | 'discord' | 'roblox' | 'robloxStudio' | 'vm'

export interface OsVersion {
  id: string
  label: string
  codename?: string
  year: number
}

export interface OsConfig {
  os: OsFamily
  version: string
  language: Language
}

export interface DraftConfig {
  os: OsFamily | null
  version: string | null
  language: Language | null
}

// Historical versions are selectable visual simulations; they do not install or boot the real OS.
export const OS_VERSIONS: Record<OsFamily, OsVersion[]> = {
  windows: [
    { id: 'win11', label: 'Windows 11', codename: '25H2 · 최신 스타일', year: 2025 },
    { id: 'win11-24h2', label: 'Windows 11', codename: '24H2', year: 2024 },
    { id: 'win11-23h2', label: 'Windows 11', codename: '23H2', year: 2023 },
    { id: 'win10', label: 'Windows 10', codename: '22H2', year: 2022 },
    { id: 'win8-1', label: 'Windows 8.1', year: 2013 },
    { id: 'win8', label: 'Windows 8', year: 2012 },
    { id: 'win7', label: 'Windows 7', year: 2009 },
    { id: 'vista', label: 'Windows Vista', year: 2007 },
    { id: 'xp', label: 'Windows XP', year: 2001 },
    { id: 'win2000', label: 'Windows 2000', year: 2000 },
    { id: 'winme', label: 'Windows Me', year: 2000 },
    { id: 'win98', label: 'Windows 98', year: 1998 },
    { id: 'win95', label: 'Windows 95', year: 1995 },
    { id: 'winnt', label: 'Windows NT 3.1', year: 1993 },
    { id: 'win31', label: 'Windows 3.1', year: 1992 },
    { id: 'win30', label: 'Windows 3.0', year: 1990 },
    { id: 'win20', label: 'Windows 2.0', year: 1987 },
    { id: 'win10-1985', label: 'Windows 1.0', year: 1985 },
  ],
  macos: [
    { id: 'tahoe', label: 'macOS 26', codename: 'Tahoe · 최신 스타일', year: 2025 },
    { id: 'sequoia', label: 'macOS 15', codename: 'Sequoia', year: 2024 },
    { id: 'sonoma', label: 'macOS 14', codename: 'Sonoma', year: 2023 },
    { id: 'ventura', label: 'macOS 13', codename: 'Ventura', year: 2022 },
    { id: 'monterey', label: 'macOS 12', codename: 'Monterey', year: 2021 },
    { id: 'bigsur', label: 'macOS 11', codename: 'Big Sur', year: 2020 },
    { id: 'catalina', label: 'macOS 10.15', codename: 'Catalina', year: 2019 },
    { id: 'mojave', label: 'macOS 10.14', codename: 'Mojave', year: 2018 },
    { id: 'high-sierra', label: 'macOS 10.13', codename: 'High Sierra', year: 2017 },
    { id: 'sierra', label: 'macOS 10.12', codename: 'Sierra', year: 2016 },
    { id: 'el-capitan', label: 'OS X 10.11', codename: 'El Capitan', year: 2015 },
    { id: 'yosemite', label: 'OS X 10.10', codename: 'Yosemite', year: 2014 },
    { id: 'mavericks', label: 'OS X 10.9', codename: 'Mavericks', year: 2013 },
    { id: 'mountain-lion', label: 'OS X 10.8', codename: 'Mountain Lion', year: 2012 },
    { id: 'lion', label: 'Mac OS X 10.7', codename: 'Lion', year: 2011 },
    { id: 'snow-leopard', label: 'Mac OS X 10.6', codename: 'Snow Leopard', year: 2009 },
    { id: 'leopard', label: 'Mac OS X 10.5', codename: 'Leopard', year: 2007 },
    { id: 'tiger', label: 'Mac OS X 10.4', codename: 'Tiger', year: 2005 },
    { id: 'panther', label: 'Mac OS X 10.3', codename: 'Panther', year: 2003 },
    { id: 'jaguar', label: 'Mac OS X 10.2', codename: 'Jaguar', year: 2002 },
    { id: 'puma', label: 'Mac OS X 10.1', codename: 'Puma', year: 2001 },
    { id: 'cheetah', label: 'Mac OS X 10.0', codename: 'Cheetah', year: 2001 },
    { id: 'macos8', label: 'Mac OS 8', year: 1997 },
    { id: 'system7', label: 'System 7', year: 1991 },
    { id: 'system1', label: 'System 1', year: 1984 },
  ],
}

export const LANGUAGES: { id: Language; label: string; native: string }[] = [
  { id: 'ko', label: 'Korean', native: '한국어' },
  { id: 'en', label: 'English', native: 'English' },
  { id: 'zh', label: 'Chinese (Simplified)', native: '简体中文' },
  { id: 'ja', label: 'Japanese', native: '日本語' },
]

export const APP_IDS: AppId[] = ['files', 'notepad', 'calculator', 'browser', 'chrome', 'discord', 'roblox', 'robloxStudio', 'vm', 'settings']

export function getVersion(os: OsFamily, versionId: string) {
  return OS_VERSIONS[os].find((v) => v.id === versionId) ?? OS_VERSIONS[os][0]
}

export function versionLabel(os: OsFamily, versionId: string) {
  const v = getVersion(os, versionId)
  return v.codename ? `${v.label} ${v.codename}` : v.label
}
