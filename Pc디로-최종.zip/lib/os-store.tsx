'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { OS_VERSIONS, type DraftConfig, type Language, type OsConfig, type OsFamily } from './os-config'

const STORAGE_KEY = 'webos-emulator:v1'

export type Phase = 'loading' | 'select' | 'booting' | 'desktop' | 'vm'

interface PersistedState {
  draft: DraftConfig
  running: OsConfig | null
  notes: string
}

const DEFAULT_STATE: PersistedState = {
  draft: { os: null, version: null, language: null },
  running: null,
  notes: '',
}

function isValidConfig(c: unknown): c is OsConfig {
  if (!c || typeof c !== 'object') return false
  const cfg = c as OsConfig
  return (
    (cfg.os === 'windows' || cfg.os === 'macos') &&
    OS_VERSIONS[cfg.os].some((v) => v.id === cfg.version) &&
    ['ko', 'en', 'zh', 'ja'].includes(cfg.language)
  )
}

function readStorage(): PersistedState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return DEFAULT_STATE
    const parsed = JSON.parse(raw) as Partial<PersistedState>
    const draft = parsed.draft && typeof parsed.draft === 'object' ? parsed.draft : DEFAULT_STATE.draft
    const selectedOs = draft.os === 'windows' || draft.os === 'macos' ? draft.os : null
    const selectedVersion = selectedOs && typeof draft.version === 'string' && OS_VERSIONS[selectedOs].some((v) => v.id === draft.version) ? draft.version : null
    const selectedLanguage = typeof draft.language === 'string' && ['ko', 'en', 'zh', 'ja'].includes(draft.language) ? draft.language as Language : null
    return {
      draft: { os: selectedOs, version: selectedVersion, language: selectedLanguage },
      running: isValidConfig(parsed.running) ? parsed.running : null,
      notes: typeof parsed.notes === 'string' ? parsed.notes : '',
    }
  } catch {
    return DEFAULT_STATE
  }
}

interface OsStore extends PersistedState {
  phase: Phase
  setPhase: (p: Phase) => void
  selectOs: (os: OsFamily) => void
  selectVersion: (version: string) => void
  selectLanguage: (language: Language) => void
  boot: (config: OsConfig) => void
  shutDown: () => void
  setNotes: (notes: string) => void
}

const OsStoreContext = createContext<OsStore | null>(null)

export function OsStoreProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<PersistedState>(DEFAULT_STATE)
  const [phase, setPhase] = useState<Phase>('loading')
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => {
    const stored = readStorage()
    setState(stored)
    setHydrated(true)
    const timer = window.setTimeout(() => setPhase(stored.running ? 'booting' : 'select'), 1400)
    return () => window.clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (!hydrated) return
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch {
      // Storage can be disabled or full; keep the current session usable.
    }
  }, [state, hydrated])

  const selectOs = useCallback((os: OsFamily) => {
    setState((s) => ({
      ...s,
      draft: { ...s.draft, os, version: s.draft.os === os ? s.draft.version : null },
    }))
  }, [])

  const selectVersion = useCallback((version: string) => {
    setState((s) => ({ ...s, draft: { ...s.draft, version } }))
  }, [])

  const selectLanguage = useCallback((language: Language) => {
    setState((s) => ({ ...s, draft: { ...s.draft, language } }))
  }, [])

  const boot = useCallback((config: OsConfig) => {
    setState((s) => ({ ...s, running: config, draft: { ...config } }))
    setPhase('booting')
  }, [])

  const shutDown = useCallback(() => {
    setState((s) => ({ ...s, running: null }))
    setPhase('select')
  }, [])

  const setNotes = useCallback((notes: string) => setState((s) => ({ ...s, notes })), [])

  const value = useMemo<OsStore>(
    () => ({ ...state, phase, setPhase, selectOs, selectVersion, selectLanguage, boot, shutDown, setNotes }),
    [state, phase, selectOs, selectVersion, selectLanguage, boot, shutDown, setNotes],
  )

  return <OsStoreContext.Provider value={value}>{children}</OsStoreContext.Provider>
}

export function useOsStore() {
  const ctx = useContext(OsStoreContext)
  if (!ctx) throw new Error('useOsStore must be used within OsStoreProvider')
  return ctx
}
