'use client'

import { useCallback, useRef, useState } from 'react'
import type { AppId } from './os-config'

export interface WindowState {
  id: AppId
  x: number
  y: number
  width: number
  height: number
  z: number
  minimized: boolean
  maximized: boolean
}

const DEFAULT_SIZES: Record<AppId, { width: number; height: number }> = {
  files: { width: 760, height: 480 },
  notepad: { width: 560, height: 420 },
  calculator: { width: 320, height: 480 },
  settings: { width: 720, height: 500 },
  browser: { width: 860, height: 560 },
  chrome: { width: 900, height: 580 },
  discord: { width: 880, height: 560 },
  roblox: { width: 900, height: 620 },
  robloxStudio: { width: 980, height: 650 },
  vm: { width: 820, height: 600 },
}

export function useWindowManager() {
  const [windows, setWindows] = useState<WindowState[]>([])
  const zCounter = useRef(10)

  const nextZ = useCallback(() => {
    zCounter.current += 1
    return zCounter.current
  }, [])

  const open = useCallback(
    (id: AppId, bounds: { width: number; height: number }) => {
      const z = nextZ()
      setWindows((ws) => {
        const existing = ws.find((w) => w.id === id)
        if (existing) {
          return ws.map((w) => (w.id === id ? { ...w, minimized: false, z } : w))
        }
        const size = DEFAULT_SIZES[id]
        const width = Math.min(size.width, bounds.width - 24)
        const height = Math.min(size.height, bounds.height - 24)
        const offset = (ws.length % 5) * 28
        const compact = bounds.width < 760 || bounds.height < 560
        return [
          ...ws,
          {
            id,
            width,
            height,
            x: Math.max(12, Math.round((bounds.width - width) / 2) - 60 + offset),
            y: Math.max(12, Math.round((bounds.height - height) / 2) - 40 + offset),
            z,
            minimized: false,
            maximized: compact,
          },
        ]
      })
    },
    [nextZ],
  )

  const fitToBounds = useCallback((bounds: { width: number; height: number }) => {
    setWindows((ws) => ws.map((w) => {
      if (w.maximized) return w
      const width = Math.max(180, Math.min(w.width, bounds.width - 8))
      const height = Math.max(140, Math.min(w.height, bounds.height - 8))
      return {
        ...w,
        width,
        height,
        x: Math.max(0, Math.min(w.x, bounds.width - width)),
        y: Math.max(0, Math.min(w.y, bounds.height - height)),
      }
    }))
  }, [])

  const close = useCallback((id: AppId) => setWindows((ws) => ws.filter((w) => w.id !== id)), [])

  const focus = useCallback(
    (id: AppId) => {
      const z = nextZ()
      setWindows((ws) => ws.map((w) => (w.id === id ? { ...w, z, minimized: false } : w)))
    },
    [nextZ],
  )

  const minimize = useCallback(
    (id: AppId) => setWindows((ws) => ws.map((w) => (w.id === id ? { ...w, minimized: true } : w))),
    [],
  )

  const toggleMaximize = useCallback(
    (id: AppId) => setWindows((ws) => ws.map((w) => (w.id === id ? { ...w, maximized: !w.maximized } : w))),
    [],
  )

  const move = useCallback(
    (id: AppId, x: number, y: number) => setWindows((ws) => ws.map((w) => (w.id === id ? { ...w, x, y } : w))),
    [],
  )

  const topWindow = windows.filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]

  return { windows, open, close, focus, minimize, toggleMaximize, move, fitToBounds, activeId: topWindow?.id ?? null }
}

export type WindowManager = ReturnType<typeof useWindowManager>
